<?php

/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/

$Dev = [*[ADMIN]*];

$helper_id = '@[*[IDHELPER]*]';
// توجه اگه ربات هلپر نباشه پنل شیشه ای بالا نمیاد



// --- @Source_Home --- //
$BotID = 1934977286; // به اینا دست نزنید
$BotID2 = 1934977286;
$PostsCH = '-1001273744025';
$plugins = [
"scoins",
"tanzimat",
"tanzimat2",
"click"
"view"
];
$cplug = count($plugins) - 1;
for($n=0; $n<=$cplug; $n++) {
  $pluginlist = "plugins/".$plugins[$n].".php";
  include($pluginlist);
}
$data = json_decode(file_get_contents("settings"),true);
$Power = $data["Power"];
$Click = $data["Click"];
$ChatIdMsg = $data["ChatIdMsg"];
$GetCoins = $data["GetCoins"];
unlink('MadelineProto.log');
 // @Source_Home
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/