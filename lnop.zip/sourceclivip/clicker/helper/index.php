<?php

// @Source_Home
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
$admin = [*[ADMIN]*]; // آیدی عددی ادمین ربات
$TOKEN = "[*[TOKENHELPER]*]"; // توکن ربات هلپر
ob_start();
define('API_KEY',"$TOKEN");
ini_set("log_errors","off");
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$textmessage = $message->text;
$inline = $update->inline_query->query;
$chatsid = $update->callback_query->from->id;
$data = $update->callback_query->data;
$inline_message_id = $update->callback_query->inline_message_id;
$database = json_decode(file_get_contents("../settings"),true);
$Power = $database["Power"];
$Click = $database["Click"];
$GetCoins = $database["GetCoins"];
$GetShetab = $database["GetShetab"];
//--- @Source_Home ---
function settings($reloadid){
$database = json_decode(file_get_contents("../settings"),true);
$Power = $database["Power"];
$Click = $database["Click"];
$GetCoins = $database["GetCoins"];
$GetShetab = $database["GetShetab"];
bot("editmessagetext", [
"text"=>"به تنظیمات ربات کلیکر خود خوشامدید🍂",
"inline_message_id"=>$reloadid,
"parse_mode"=>"MarkDown",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text" => "📍وضعیت ربات📍", "callback_data" => "H_bot"],["text" => "➰ $Power ➰", "callback_data" => "bot"]],
[["text" => "🎗جمع آوری سکه🎗", "callback_data" => "H_bazdidgir_ping"],["text" => "➰ $GetCoins ➰", "callback_data" => "bazdidgir_ping"]],
[["text" => "برگشت | Back", "callback_data" => "back"]]
]
])
]);
}
//------
if($textmessage == "/start"){
bot("sendMessage",[
"chat_id"=>$chat_id,
"text"=>":D",
"parse_mode"=>"MarkDown",
]);
}
if($inline == "panel"){
bot("answerInlineQuery",[
"inline_query_id"=>$update->inline_query->id,
"results"=>json_encode([[
"type"=>"article",
"id"=>base64_encode(rand(5,555)),
"title"=>"managment",
"input_message_content"=>["parse_mode"=>"MarkDown","message_text"=>"پنل مدیریت ربات کلیکر | نسخه 9.9"],
"reply_markup"=>["inline_keyboard"=>[
[["text"=>"⚙️تنظیمات ربات⚙️","callback_data"=>"panel"],["text"=>"راهنمای دستورات🎈","callback_data"=>"help"]],
]]
]])
]);
}
if($data == "panel" && $chatsid == $admin){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
"text"=>"در حال پردازش ..."
]);
settings($inline_message_id);
}
if($data == "help" && $chatsid == $admin){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
"text"=>"در حال پردازش ..."
]);
bot("editmessagetext", [
"text"=>"راهنمای ربات کلیکر عقاب (ای‌بازدید)❄️

🔺+🔻
روشن کردن ربات
〰️〰️〰️〰️〰️〰️〰️〰️〰️
🔺-🔻
خاموش کردن ربات
〰️〰️〰️〰️〰️〰️〰️〰️〰️
🔺موجودی🔻
دریافت موجودی در ربات ای بازدید
〰️〰️〰️〰️〰️〰️〰️〰️〰️
🔺جوین | /join🔻
عضویت خودکار در کانال ها و ربات اصلی ای‌بازدید
〰️〰️〰️〰️〰️〰️〰️〰️〰️
🔺پنل | منو | مدیریت | فهرست🔻
دریافت پنل تنظیمات شیشه ای
〰️〰️〰️〰️〰️〰️〰️〰️〰️",
"inline_message_id"=>$inline_message_id,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[
["text" => "برگشت | Back", "callback_data" => "back"]
]
]
])
]);
}
//--- @Source_Home ---
if($data == "H_bot" && $chatsid == $admin){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
"text"=>"این بخش مربوط به روشن و خاموش کردن ربات  است.
اگر ربات خاموش باشد جمع آوری سکه به کلی خاموش میشود!",
'show_alert' => true
]);
}
if($data == "H_bazdidgir_ping" && $chatsid == $admin){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
"text"=>"این بخش مربوط به روشن و خاموش کردن جمع آوری سکه در ربات بازدیدگیر است.",
'show_alert' => true
]);
}
if($data == "back" && $chatsid == $admin){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
"text"=>"در حال برگشت به منوی اصلی ..."
]);
bot("editmessagetext", [
"text"=>"پنل مدیریت ربات کلیکر | نسخه 9.9",
"inline_message_id"=>$inline_message_id,
"parse_mode"=>"MarkDown",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"⚙️تنظیمات ربات⚙️","callback_data"=>"panel"],["text"=>"راهنمای دستورات🎈","callback_data"=>"help"]],
]
])
]);
}
if($data == "bot" && $chatsid == $admin){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
"text"=>"در حال پردازش ..."
]);
$database = json_decode(file_get_contents("../settings"),true);
if($Power == "on"){
$database["Power"] = "off";
$outjson = json_encode($database,true);
file_put_contents("../settings",$outjson);
settings($inline_message_id);
}
if($Power == "off"){
$database["Power"] = "on";
$outjson = json_encode($database,true);
file_put_contents("../settings",$outjson);
settings($inline_message_id);
}
}
if($data == "bazdidgir_shetab" && $chatsid == $admin){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
"text"=>"در حال پردازش ..."
]);
$database = json_decode(file_get_contents("../settings"),true);
if($GetShetab == "on"){
$database["GetShetab"] = "off";
$outjson = json_encode($database,true);
file_put_contents("../settings",$outjson);
settings($inline_message_id);
}
if($GetShetab == "off"){
$database["GetShetab"] = "on";
$outjson = json_encode($database,true);
file_put_contents("../settings",$outjson);
settings($inline_message_id);
}
}
if($data == "bazdidgir_ping" && $chatsid == $admin){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
"text"=>"در حال پردازش ..."
]);
$database = json_decode(file_get_contents("../settings"),true);
if($GetCoins == "on"){
$database["GetCoins"] = "off";
$outjson = json_encode($database,true);
file_put_contents("../settings",$outjson);
settings($inline_message_id);
}
if($GetCoins == "off"){
$database["GetCoins"] = "on";
$outjson = json_encode($database,true);
file_put_contents("../settings",$outjson);
settings($inline_message_id);
}
}
if($data == "plus_click" && $chatsid == $admin){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
"text"=>"در حال پردازش ..."
]);
$database = json_decode(file_get_contents("../settings"),true);
settype($Click,"integer");
$newbots_click_count = $Click + 1;
$database['Click'] = $newbots_click_count;
$database['ClickCount'] = 0;
$outjson = json_encode($database,true);
file_put_contents("../settings",$outjson);
settings($inline_message_id);
}
// @Source_Home
if($data == "min_click" && $chatsid == $admin){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
"text"=>"در حال پردازش ..."
]);
$database = json_decode(file_get_contents("../settings"),true);
settype($Click,"integer");
$newbots_click_count = $Click - 1;
$database['Click'] = $newbots_click_count;
$database['ClickCount'] = 0;
$outjson = json_encode($database,true);
file_put_contents("../settings",$outjson);
settings($inline_message_id);
}
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
// @Source_Home