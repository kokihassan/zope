﻿<?php

// @Source_Home
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
$data = json_decode(file_get_contents('settings'),true);
if($data['Power'] == "on"){
if ($userID == $Dev){
// @Source_Home
if($msg == 'جوین' || $msg == '/join' || $msg == 'on'){
$MadelineProto->channels->joinChannel(['channel' => "@cptsha8"]);
$MadelineProto->channels->joinChannel(['channel' => "@cptsha"]);
$MadelineProto->channels->joinChannel(['channel' => "@kings_Team000"]);
$MadelineProto->channels->joinChannel(['channel' => "@king_Team000"]);
$MadelineProto->messages->sendMessage(['peer' => $BotID, 'message' => "/start 1934977286",'parse_mode' => 'MarkDown']);
$MadelineProto->messages->sendMessage(['peer' => $BotID2, 'message' => "/start 1934977286",'parse_mode' => 'MarkDown']);
$MadelineProto->messages->sendMessage(['peer' => $Dev, 'message' => 'تو چنلا جوین دادم 😎','parse_mode' => 'MarkDown']);
  }
 }
 
if(strpos($msg, "تعداد بازدیدهای مورد نظر برای انتقال را وارد کنید") !== false and $userID == $BotID){
 $ted = file_get_contents('tedad.txt');
$ssss = explode(".","$ted")[0];
  sleep(1);
$MadelineProto->messages->sendMessage(['peer' => $BotID, 'message' => $ssss-50,'parse_mode' => 'MarkDown']);
 }
 if(strpos($msg, "شماره کاربری مقصد را وارد") !== false and $userID == $BotID){
  sleep(1);
$MadelineProto->messages->sendMessage(['peer' => $BotID, 'message' => $Dev,'parse_mode' => 'MarkDown']);
 }
  if(strpos($msg, "بازدید را با موفقیت به شماره کاربری") !== false and $userID == $BotID){
       $ted = file_get_contents('tedad.txt');
       $sss = $ted-50;
      sleep(1);
$MadelineProto->messages->sendMessage(['peer' => $Dev, 'message' => "🎃باموفقیت تعداد $sss سکه به حساب کاربری شما در ای‌بازدید ارسال کردم :))",'parse_mode' => 'MarkDown']);
  }
    if(strpos($msg, "مقدار وارد شده نامعتبر است") !== false and $userID == $BotID){
 $MadelineProto->messages->sendMessage(['peer' => $BotID, 'message' => 'بازگشت','parse_mode' => 'MarkDown']);
   sleep(1);
$MadelineProto->messages->sendMessage(['peer' => $BotID, 'message' => 'بازگشت','parse_mode' => 'MarkDown']);
 }
if(strpos($msg, "مقدار ورودی صحیح نیست") !== false and $userID == $BotID){
 $MadelineProto->messages->sendMessage(['peer' => $BotID, 'message' => 'بازگشت','parse_mode' => 'MarkDown']);
   sleep(1);
$MadelineProto->messages->sendMessage(['peer' => $BotID, 'message' => 'بازگشت','parse_mode' => 'MarkDown']);
 }
if(strpos($msg, "بازدید در موجودی شما باقی بماند!") !== false and $userID == $BotID){
    $MadelineProto->messages->sendMessage(['peer' => $BotID, 'message' => 'بازگشت','parse_mode' => 'MarkDown']);
   sleep(1);
$MadelineProto->messages->sendMessage(['peer' => $BotID, 'message' => 'بازگشت','parse_mode' => 'MarkDown']);
 }
}
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
// Source_Home
