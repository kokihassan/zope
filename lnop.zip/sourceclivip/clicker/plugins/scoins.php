<?php
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
// Source_Home //

$data = json_decode(file_get_contents('settings'),true);
if($data['Power'] == "on"){
if($data["GetCoins"] == "on"){
 if(!file_exists('send.txt')){
file_put_contents('send.txt','@cptsha8');
 }
 if(!file_exists('click.txt')){
file_put_contents('click.txt','cptsha8');
 }
 if((time() - filectime('send.txt')) > 90){
 unlink('send.txt');
 unlink('send.txt');
   $MadelineProto->messages->sendMessage(['peer' => $BotID,'message' => "🔐 مشخصات کاربری",'parse_mode' => 'MarkDown']);
   sleep(1); file_put_contents('send.txt','@Source_Home');
 }
  }
   }
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
// @Source_Home
