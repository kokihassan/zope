﻿<?php
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
// @Source_Home

if($msg == "+" and $userID == $Dev){
$data['Power'] = "on";
// @Source_Home
$outjson = json_encode($data,true);
file_put_contents("settings",$outjson);
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "✅ کلیکر روشن شد",'reply_to_msg_id' => $msg_id,]);
}
if($msg == "-" and $userID == $Dev){
$data['Power'] = "off";
$outjson = json_encode($data,true);
file_put_contents("settings",$outjson);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "❌ کلیکر خاموش شد",'reply_to_msg_id' => $msg_id,]);
}
$data = json_decode(file_get_contents('settings'),true);
if($data['Power'] == "on"){
if ($userID == $Dev){
if($msg == 'پنل' || $msg=='panel' || $msg=='/panel' || $msg=='Panel' || $msg=='مدیریت' || $msg=='منو' || $msg=='فهرست'){
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => $helper_id, 'peer' => $chatID, 'query' => "panel", 'offset' => '-2', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
// @Source_Home
if($msg == 'ping' || $msg == 'Ping' || $msg == 'ربات' || $msg == 'آنلاینی' || $msg == 'انلاینی'){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "✅ Online :D",]);
}
if($msg == 'موجودی'){
$data["ChatIdMsg"] = $chatID;
$outjson = json_encode($data,true);
file_put_contents("settings",$outjson);
file_put_contents('true.txt','true');
$MadelineProto->messages->sendMessage(['peer' => $BotID,'message' =>'🔐 مشخصات کاربری','parse_mode' => 'MarkDown']);
  }
 }

if(strpos($msg, "موجودی") !== false && $userID == $BotID){
$data["ChatIdMsg"] = '';
$outjson = json_encode($data,true);
file_put_contents("settings",$outjson);
$a = explode("✅موجودی شما:  ",$msg)[1];
$tedadecoins = explode(" ","$a")[0];
file_put_contents('tedad.txt',$tedadecoins);
if(file_get_contents('true.txt') == 'true'){
$ted = file_get_contents('tedad.txt');
$MadelineProto->messages->sendMessage(['peer' => $ChatIdMsg, 'message' => "🌀 تعداد سکه های شما در ای‌بازدید: $ted",'parse_mode' => 'MarkDown']);
file_put_contents('true.txt','false');
}else{
$ted = file_get_contents('tedad.txt');
if($ted > 100){
sleep(1);
$MadelineProto->messages->sendMessage(['peer' => $BotID, 'message' => "انتقال بازدید",'parse_mode' => 'MarkDown']);
   }
  }
 }
}
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
// Source_Home
