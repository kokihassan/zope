<?php
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
// @Source_Home

ini_set(set_time_limit(-4));
if(isset($update['update']['message'])){
if($chatID == $PostsCH){
  $MadelineProto->messages->getMessagesViews(['peer' => $chatID, 'id' => [$msg_id], 'increment' => true, ]);
   }
$data = json_decode(file_get_contents('settings'),true);
if($data["Power"] == "on"){
if($data["GetCoins"] == "on"){
if((time() - filectime('click.txt')) > 300){ unlink('click.txt');
$MadelineProto->messages->sendMessage(['peer' => $Dev, 'message' => "🚦رفتم حالت جمع آوری سکه..
❕ چند دقیقه طول خواهد کشید لطفا تا اتمام عملیات هیچ دستوری ارسال نکنید"]);
$Source_Home = $MadelineProto->messages->getHistory(['peer' => '@cptsha8', 'offset_id' => 0, 'offset_date' => 0, 'add_offset' => 0, 'limit' => 30, 'max_id' => 0, 'min_id' => 0, 'hash' => 0 ]);
	foreach($Source_Home['messages'] as $message){
	foreach($message['reply_markup']['rows'] as $row){
foreach($row['buttons'] as $button){
$mn = $button['text'];
if(strpos($mn, 'ثبت') !== false){
$button->click();
      }
     }
    }
   }
   $MadelineProto->messages->sendMessage(['peer' => $Dev, 'message' => "🚦از حالت جمع آوری سکه در اومدم میتونی دستور بدی!"]); file_put_contents('send.txt','@Source_Home');
   }
  }
 }
}
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
?>