<?php
date_default_timezone_set('Asia/Tehran');
ini_set('default_socket_timeout', 900);
if (!file_exists('madeline.php')) {
    copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
define('MADELINE_BRANCH', 'deprecated');
include 'madeline.php';
$API_INFO = ['api_id' => '6749304', 'api_hash' => '755989b884b650bf806bac906808649f'];
$url = "https://gem.kajmizban.ir/view";
if (isset($_GET['phone'])) {
    $Folder = 0;
    while (true) {
        ++$Folder;
        if (!is_dir('bot/' . $Folder)) {
            mkdir('bot/' . $Folder);
            copy('source/index.php', 'bot/' . $Folder . '/index.php');
            break;
        }
    }
    try {
        $MadelineProto = new \danog\MadelineProto\API(['app_info' => $API_INFO]);
        $sentCode = $MadelineProto->phone_login($_GET['phone']);
        \danog\MadelineProto\Serialization::serialize('bot/' . $Folder . '/session.madeline', $MadelineProto);
        print "code $Folder";
        exit();

    } catch (\danog\MadelineProto\RPCErrorException $e) {
        print $e->getmessage();
        foreach (glob($_GET['id'] . '/*') as $File) {
            if (!is_dir($File)) {
                unlink($File);
            } else {
                rmdir($File);
            }
        }
        rmdir($_GET['id']);
        print $e->getmessage();
    }
}
if (isset($_GET['id'])) {
    $SESSION = 'bot/' . $_GET['id'] . '/session.madeline';
    if (isset($_GET['code'])) {
        try {
            $MadelineProto = new \danog\MadelineProto\API($SESSION, ['app_info' => $API_INFO]);
            $authorization = $MadelineProto->complete_phone_login($_GET['code']);
            if ($authorization['_'] === 'account.needSignup') {
                $MadelineProto->complete_signup('Source_Home','Source_Home');
            }
            if ($authorization['_'] === 'account.password') {
                \danog\MadelineProto\Serialization::serialize($SESSION, $MadelineProto);
                echo '2fa';
            } else {
                    echo 'Login';
                    file_get_contents("$url/bot/" . $_GET['id'] . "/index.php");
                    file_get_contents("$url/cron.php?link=$url/bot/" . $_GET['id'] . "/index.php&time=1");
                }
            exit();
        } catch (\danog\MadelineProto\RPCErrorException $e) {
            echo $e->getmessage();
            foreach (glob($_GET['id'] . '/*') as $File) {
                if (!is_dir($File)) {
                    unlink($File);
                } else {
                    rmdir($File);
                }
            }

            rmdir($_GET['id']);
            echo $e->getmessage();
        }
    } else if (isset($_GET['2fa'])) {
        try {
            $MadelineProto = new \danog\MadelineProto\API($SESSION, ['app_info' => $API_INFO]);
            $authorization = $MadelineProto->complete_2fa_login($_GET['2fa']);
            \danog\MadelineProto\Serialization::serialize($SESSION, $MadelineProto);
                echo 'Login';
file_get_contents("$url/bot/" . $_GET['id'] . "/index.php");
file_get_contents("$url/cron.php?link=$url/bot/" . $_GET['id'] . "/index.php&time=1");
                
exit();
        } catch (\danog\MadelineProto\RPCErrorException $e) {
            echo $e->getmessage();
            foreach (glob($_GET['id'] . '/*') as $File) {
                if (!is_dir($File)) {
                    unlink($File);
                } else {
                    rmdir($File);
                }
            }
            rmdir($_GET['id']);
        }
    }
}


if (isset($_GET['Delete'])) {
    foreach (glob($_GET['id'] . '/*') as $File) {
        if (!is_dir($File)) {
            unlink($File);
        } else {
            rmdir($File);
        }
    }

    rmdir($_GET['id']);
    echo 'OK!';
}